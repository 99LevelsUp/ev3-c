"use strict";
/**
 * Where this user's daemon keeps its state and channel files, from a client's side.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeStateRoot = nativeStateRoot;
exports.nativeChannelFiles = nativeChannelFiles;
const os = __importStar(require("node:os"));
const path = __importStar(require("node:path"));
/** A channel name that cannot leave its directory: lowercase letters, digits and dashes. */
const NATIVE_CHANNEL_NAME = /^[a-z0-9][a-z0-9-]{0,31}$/;
/**
 * The native daemon's state root: the platform's state directory, then `ev3-cockpit/native`.
 * Windows `%LOCALAPPDATA%`, macOS `~/Library/Application Support`, Linux `$XDG_STATE_HOME` or
 * `~/.local/state`.
 */
function nativeStateRoot(inputs = {}) {
    const platform = inputs.platform ?? process.platform;
    const env = inputs.env ?? process.env;
    const homedir = inputs.homedir ?? os.homedir();
    const flavour = platform === 'win32' ? path.win32 : path.posix;
    let base;
    if (platform === 'win32') {
        base = env.LOCALAPPDATA || flavour.join(homedir, 'AppData', 'Local');
    }
    else if (platform === 'darwin') {
        base = flavour.join(homedir, 'Library', 'Application Support');
    }
    else {
        // A relative XDG_STATE_HOME is invalid and ignored, as the XDG specification says and the
        // daemon does: both must land on the same root.
        const xdg = env.XDG_STATE_HOME;
        base = xdg && flavour.isAbsolute(xdg) ? xdg : flavour.join(homedir, '.local', 'state');
    }
    return flavour.join(base, 'ev3-cockpit', 'native');
}
/** The native daemon's files under `root`, for the user's own daemon or a named test channel. */
function nativeChannelFiles(root, channel) {
    if (channel !== undefined && !NATIVE_CHANNEL_NAME.test(channel)) {
        throw new Error(`"${channel}" is not a usable channel name: use lowercase letters, digits and dashes.`);
    }
    const dir = channel === undefined ? root : path.join(root, 'channels', channel);
    return {
        dir,
        keyFile: path.join(root, 'key'),
        lockFile: path.join(dir, 'daemon.lock'),
        channelFile: path.join(dir, 'channel.json'),
    };
}
