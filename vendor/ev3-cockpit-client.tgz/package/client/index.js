"use strict";
/**
 * The cockpit client library: what the VS Code extension, the `ev3` command, MCP servers and
 * add-ons use to work with bricks through the user's native daemon, `ev3-cockpitd`.
 *
 * - It finds this user's daemon or starts a verified copy of it, and proves both sides hold the
 *   user's key.
 * - It keeps the bricks, the settings and the access mode current from the daemon's notifications,
 *   so reading them needs no round trip.
 * - When the daemon goes, it connects again and renews every subscription, each with a fresh
 *   snapshot first. Nothing is handed over between daemons.
 * - Questions for a person go to the handler the caller set; without one it answers `keep`.
 *
 * The contract is the one generated from the JSON Schema in `contract/`; `docs/api-for-consumers.md`
 * describes what an add-on uses.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeStateRoot = exports.nativeChannelFiles = exports.recordNativeInstall = exports.packagedDaemon = exports.nativeInstallFile = exports.installedNativeLaunch = exports.developmentDaemon = exports.daemonBinaryName = exports.DaemonStartError = exports.DAEMON_MANIFEST = exports.ensureNativeDaemon = exports.decideOnDaemon = exports.NATIVE_READINESS_MS = exports.EXIT_ANSWER_MS = exports.SUCCESSOR_WAIT_MS = exports.CockpitClient = exports.ContractError = exports.WireErrorCode = void 0;
__exportStar(require("../contract/generated"), exports);
var errors_1 = require("../contract/errors");
Object.defineProperty(exports, "WireErrorCode", { enumerable: true, get: function () { return errors_1.WireErrorCode; } });
var connection_1 = require("./connection");
Object.defineProperty(exports, "ContractError", { enumerable: true, get: function () { return connection_1.ContractError; } });
var nativeClient_1 = require("./nativeClient");
Object.defineProperty(exports, "CockpitClient", { enumerable: true, get: function () { return nativeClient_1.CockpitClient; } });
Object.defineProperty(exports, "SUCCESSOR_WAIT_MS", { enumerable: true, get: function () { return nativeClient_1.SUCCESSOR_WAIT_MS; } });
var nativeDaemon_1 = require("./nativeDaemon");
Object.defineProperty(exports, "EXIT_ANSWER_MS", { enumerable: true, get: function () { return nativeDaemon_1.EXIT_ANSWER_MS; } });
Object.defineProperty(exports, "NATIVE_READINESS_MS", { enumerable: true, get: function () { return nativeDaemon_1.NATIVE_READINESS_MS; } });
Object.defineProperty(exports, "decideOnDaemon", { enumerable: true, get: function () { return nativeDaemon_1.decideOnDaemon; } });
Object.defineProperty(exports, "ensureNativeDaemon", { enumerable: true, get: function () { return nativeDaemon_1.ensureNativeDaemon; } });
var nativeLaunch_1 = require("./nativeLaunch");
Object.defineProperty(exports, "DAEMON_MANIFEST", { enumerable: true, get: function () { return nativeLaunch_1.DAEMON_MANIFEST; } });
Object.defineProperty(exports, "DaemonStartError", { enumerable: true, get: function () { return nativeLaunch_1.DaemonStartError; } });
Object.defineProperty(exports, "daemonBinaryName", { enumerable: true, get: function () { return nativeLaunch_1.daemonBinaryName; } });
Object.defineProperty(exports, "developmentDaemon", { enumerable: true, get: function () { return nativeLaunch_1.developmentDaemon; } });
Object.defineProperty(exports, "installedNativeLaunch", { enumerable: true, get: function () { return nativeLaunch_1.installedNativeLaunch; } });
Object.defineProperty(exports, "nativeInstallFile", { enumerable: true, get: function () { return nativeLaunch_1.nativeInstallFile; } });
Object.defineProperty(exports, "packagedDaemon", { enumerable: true, get: function () { return nativeLaunch_1.packagedDaemon; } });
Object.defineProperty(exports, "recordNativeInstall", { enumerable: true, get: function () { return nativeLaunch_1.recordNativeInstall; } });
var locate_1 = require("./locate");
Object.defineProperty(exports, "nativeChannelFiles", { enumerable: true, get: function () { return locate_1.nativeChannelFiles; } });
Object.defineProperty(exports, "nativeStateRoot", { enumerable: true, get: function () { return locate_1.nativeStateRoot; } });
