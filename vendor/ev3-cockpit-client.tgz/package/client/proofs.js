"use strict";
/**
 * The proofs of the hello: each side shows it holds the user's key with an HMAC over both nonces,
 * labelled by who proves. `docs/channel.md` is the written rule; the daemon computes the same.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.newNonce = newNonce;
exports.daemonProof = daemonProof;
exports.clientProof = clientProof;
exports.proofsMatch = proofsMatch;
const node_crypto_1 = require("node:crypto");
/** A fresh nonce, hex. */
function newNonce() {
    return (0, node_crypto_1.randomBytes)(32).toString('hex');
}
function proof(key, label, clientNonce, daemonNonce) {
    return (0, node_crypto_1.createHmac)('sha256', key).update(`${label}\n${clientNonce}\n${daemonNonce}`).digest('hex');
}
function daemonProof(key, clientNonce, daemonNonce) {
    return proof(key, 'daemon', clientNonce, daemonNonce);
}
function clientProof(key, clientNonce, daemonNonce) {
    return proof(key, 'client', clientNonce, daemonNonce);
}
/** Compares two hex proofs in constant time. */
function proofsMatch(expected, given) {
    if (typeof given !== 'string' || given.length !== expected.length) {
        return false;
    }
    return (0, node_crypto_1.timingSafeEqual)(Buffer.from(expected, 'utf8'), Buffer.from(given, 'utf8'));
}
