/**
 * Which side is newer, and what to tell the user about it.
 *
 * A client built in this repository (the VS Code extension, the `ev3` command, the cockpit's MCP
 * server) compares package versions: the newest wins, so a newer client asks the daemon to step
 * aside once it is idle. An add-on carries no daemon and compares only the contract version.
 */
import type { ClientKind } from '../contract/generated';
/** Compares dotted versions numerically: negative when `a` is older. */
export declare function compareVersions(a: string, b: string): number;
export declare function isRepoClient(kind: ClientKind): boolean;
export interface VersionNotice {
    readonly current: string;
    readonly newer: string;
    readonly newerIs: 'client' | 'daemon';
    readonly text: string;
}
/** What a repository client should say, or nothing when the versions match. */
export declare function versionNotice(clientVersion: string, daemonVersion: string): VersionNotice | undefined;
/** What an add-on should say when the daemon's contract cannot serve it. */
export declare function contractNotice(needed: number, offered: number): string | undefined;
