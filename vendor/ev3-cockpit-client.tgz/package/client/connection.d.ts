/**
 * One end of a contract connection: JSON-RPC 2.0 framed the way LSP frames it, over any duplex
 * stream — a named pipe, a unix socket, or a pair of streams in a test.
 *
 * Built on `vscode-jsonrpc`, with three things it does not do on its own:
 * - when the stream closes, every pending request fails with `daemon_unavailable` instead of
 *   waiting forever: at once when this side closes, and when the other side ends the stream, right
 *   after the answers and notifications it sent before the end have been handled;
 * - a message larger than the cap closes the connection, so a broken or hostile peer cannot make
 *   this process buffer without limit;
 * - a cancelled request is answered with the contract's own `cancelled` error.
 *
 * Both the daemon and its clients use it.
 */
import { Duplex } from 'node:stream';
import { WireErrorCode, WireErrorData } from '../contract/errors';
/** A message larger than this closes the connection. */
export declare const DEFAULT_MAX_MESSAGE_BYTES: number;
/** An error that crossed the wire, or one this side raises with a contract code. */
/** A refusal a person can lift: `command` is what they can run. */
export declare function needsPerson(message: string, command: string): ContractError;
/**
 * A contract error: decide on `code`. `data` is the contract's `ErrorData` — the code, its family,
 * and `holder`, `candidates` or `command` where the code has them.
 */
export declare class ContractError extends Error {
    readonly code: WireErrorCode;
    readonly data: WireErrorData;
    constructor(code: WireErrorCode, message: string, extra?: Partial<Omit<WireErrorData, 'code'>>);
}
/** What a request handler gets besides its parameters. */
export interface RequestContext {
    /** Aborts when the caller cancels or the connection closes. */
    readonly signal: AbortSignal;
    /** Reports progress, when the caller asked for it. */
    progress(value: unknown): void;
}
export type RequestHandler = (params: unknown, context: RequestContext) => unknown;
export interface RequestOptions {
    readonly signal?: AbortSignal;
    readonly onProgress?: (value: unknown) => void;
}
export interface Endpoint {
    request<T = unknown>(method: string, params?: unknown, options?: RequestOptions): Promise<T>;
    notify(method: string, params?: unknown): void;
    onRequest(method: string, handler: RequestHandler): void;
    /** Handles every request no `onRequest` handler took; the method name comes first. */
    onAnyRequest(handler: (method: string, params: unknown) => unknown): void;
    onNotification(method: string, handler: (params: unknown) => void): void;
    /** Called once, when the connection closes for any reason. */
    onClose(listener: () => void): void;
    readonly closed: boolean;
    close(): void;
}
export interface EndpointOptions {
    readonly maxMessageBytes?: number;
    /** Told when a message over the cap closed the connection. */
    readonly onOversize?: (bytes: number) => void;
}
export declare function createEndpoint(stream: Duplex, options?: EndpointOptions): Endpoint;
