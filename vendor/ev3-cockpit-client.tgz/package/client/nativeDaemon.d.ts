/**
 * Which native daemon a client works with, from the client's side. The daemon judges an exit
 * request itself; the client decides when to ask.
 *
 * - No daemon: the client starts its own verified copy.
 * - A daemon runs: the hello says its version, contract version and build kind.
 *   - A development client meeting a release daemon asks it to exit and starts its own.
 *   - A release client newer than a release daemon asks it to exit, then starts its own.
 *   - A release client meeting a development daemon uses it and tells the user one runs.
 *   - Otherwise the client uses it.
 *   - A client that would use a daemon on another contract version says so and stops.
 * - Only the VS Code extension and the `ev3` command, which carry a daemon, ever ask a daemon to
 *   exit. An add-on starts the installed cockpit's daemon from `install.json`; the MCP server asks
 *   nothing either.
 * - An exit request may take up to two minutes to answer (a person's answer, then a write still
 *   running). Its answer is `{accepted, reason}`; once accepted the daemon is ending, so the client
 *   waits for its channel to go before it starts its own.
 */
import type { BuildKind, ChannelRecord, ClientKind, DaemonExitResult, LaunchSpec } from '../contract/generated';
import { NativeChannelHost } from './channel';
import { Endpoint } from './connection';
import { DaemonIdentity, KeyReadHost } from './hello';
import { NativeChannelFiles } from './locate';
import { LaunchHost } from './nativeLaunch';
/** How long starting a daemon, or waiting for one to end, may take. */
export declare const NATIVE_READINESS_MS = 15000;
/** How long the client waits for the answer to an exit request: a person's 60 s, then a write's 60 s. */
export declare const EXIT_ANSWER_MS = 130000;
/** Who the client is, as the launch decides. */
export interface LaunchingClient {
    readonly kind: ClientKind;
    readonly buildKind: BuildKind;
    readonly version: string;
    readonly contractVersion: number;
    /** The client carries a daemon it could start in place of the running one. */
    readonly canStart: boolean;
}
export type LaunchDecision = {
    readonly action: 'use';
    readonly notice?: string;
} | {
    readonly action: 'replace';
} | {
    readonly action: 'stop';
    readonly reason: string;
};
/** What a client does about a daemon it met. */
export declare function decideOnDaemon(client: LaunchingClient, daemon: Pick<DaemonIdentity, 'version' | 'buildKind' | 'contractVersion'>): LaunchDecision;
export interface NativeDaemonOptions {
    /** Shown in the daemon's log, in other clients' `brick_busy` and in questions. */
    readonly name: string;
    readonly kind: ClientKind;
    /** This client's package version. */
    readonly version: string;
    /** This client's build kind; by default its daemon's, and `release` for a client that carries none. */
    readonly buildKind?: BuildKind;
    /**
     * The daemon this client carries: `packagedDaemon` or `developmentDaemon`. An add-on carries
     * none; it starts the one the installed cockpit recorded.
     */
    readonly daemon?: LaunchSpec;
    /** The state root; by default the platform's. A root of its own needs a test channel. */
    readonly stateRoot?: string;
    /** A test channel; by default the user's own. */
    readonly channel?: string;
    /** More arguments for a daemon this client starts on a test channel: replay and its recording. */
    readonly daemonArgs?: readonly string[];
    readonly readinessMs?: number;
    readonly exitAnswerMs?: number;
    /** Before starting a daemon, wait this long for another client's (a replacement on its way). */
    readonly successorWaitMs?: number;
    /** Told what the user should know: a development daemon runs, an exit request was refused. */
    readonly onNotice?: (text: string) => void;
    readonly host?: LaunchHost;
    readonly channelHost?: NativeChannelHost;
    readonly keyHost?: KeyReadHost;
}
export interface NativeDaemonConnection {
    readonly endpoint: Endpoint;
    readonly daemon: DaemonIdentity;
    readonly record: ChannelRecord;
    readonly files: NativeChannelFiles;
    /** This client started the daemon it is connected to. */
    readonly started: boolean;
}
/**
 * Connects to the daemon this client should work with, starting or replacing one as the rules
 * above say. Throws a `DaemonStartError` when it cannot.
 */
export declare function ensureNativeDaemon(options: NativeDaemonOptions): Promise<NativeDaemonConnection>;
/**
 * Asks a daemon to exit and waits for its answer. A daemon that goes meanwhile counts as ending,
 * and so does one that cancelled the request: it does that only as it shuts down, when another
 * client's exit request came first.
 */
export declare function askToExit(endpoint: Endpoint, timeoutMs: number): Promise<DaemonExitResult>;
