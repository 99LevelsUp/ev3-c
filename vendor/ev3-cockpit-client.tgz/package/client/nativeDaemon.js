"use strict";
/**
 * Which native daemon a client works with, from the client's side. The daemon judges an exit
 * request itself; the client decides when to ask.
 *
 * - No daemon: the client starts its own verified copy.
 * - A daemon runs: the hello says its version, contract version and build kind.
 *   - A development client meeting a release daemon asks it to exit and starts its own.
 *   - A release client newer than a release daemon asks it to exit, then starts its own.
 *   - A release client meeting a development daemon uses it and tells the user one runs.
 *   - Otherwise the client uses it.
 *   - A client that would use a daemon on another contract version says so and stops.
 * - Only the VS Code extension and the `ev3` command, which carry a daemon, ever ask a daemon to
 *   exit. An add-on starts the installed cockpit's daemon from `install.json`; the MCP server asks
 *   nothing either.
 * - An exit request may take up to two minutes to answer (a person's answer, then a write still
 *   running). Its answer is `{accepted, reason}`; once accepted the daemon is ending, so the client
 *   waits for its channel to go before it starts its own.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.EXIT_ANSWER_MS = exports.NATIVE_READINESS_MS = void 0;
exports.decideOnDaemon = decideOnDaemon;
exports.ensureNativeDaemon = ensureNativeDaemon;
exports.askToExit = askToExit;
const path = __importStar(require("node:path"));
const errors_1 = require("../contract/errors");
const generated_1 = require("../contract/generated");
const channel_1 = require("./channel");
const connection_1 = require("./connection");
const hello_1 = require("./hello");
const locate_1 = require("./locate");
const nativeLaunch_1 = require("./nativeLaunch");
const versions_1 = require("./versions");
/** How long starting a daemon, or waiting for one to end, may take. */
exports.NATIVE_READINESS_MS = 15_000;
/** How long the client waits for the answer to an exit request: a person's 60 s, then a write's 60 s. */
exports.EXIT_ANSWER_MS = 130_000;
/** How many times the client meets a daemon and decides again before it gives up. */
const MAX_ROUNDS = 5;
/** How long without a channel after a lock-held exit before the client starts its copy again. */
const RESPAWN_AFTER_MS = 1_000;
function describeDaemon(daemon) {
    return daemon.buildKind === 'development'
        ? `A development build of the EVƎ Cockpit daemon (version ${daemon.version})`
        : `The EVƎ Cockpit daemon ${daemon.version}`;
}
function contractStop(daemon, clientContract, why = '') {
    return `${describeDaemon(daemon)} runs and speaks contract ${daemon.contractVersion}; this client speaks contract ${clientContract}, so it cannot use it.${why ? ` ${why}` : ''} Update the older of the two.`;
}
/** What a client does about a daemon it met. */
function decideOnDaemon(client, daemon) {
    const mayReplace = client.canStart && (client.kind === 'vscode' || client.kind === 'cli');
    if (mayReplace && daemon.buildKind === 'release'
        && (client.buildKind === 'development' || (0, versions_1.compareVersions)(client.version, daemon.version) > 0)) {
        return { action: 'replace' };
    }
    if (daemon.contractVersion !== client.contractVersion) {
        return { action: 'stop', reason: contractStop(daemon, client.contractVersion) };
    }
    if (client.buildKind === 'release' && daemon.buildKind === 'development') {
        return { action: 'use', notice: `${describeDaemon(daemon)} runs; this client uses it.` };
    }
    return { action: 'use' };
}
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
function isUnavailable(error) {
    return error instanceof connection_1.ContractError && error.code === errors_1.WireErrorCode.DaemonUnavailable && !(error instanceof nativeLaunch_1.DaemonStartError);
}
/** The arguments that put a daemon on the client's channel and state root. */
function channelArgs(options, stateRoot) {
    if (!options.channel) {
        if (options.stateRoot !== undefined || options.daemonArgs?.length) {
            throw new Error('A state root of its own and daemon arguments need a test channel.');
        }
        return [];
    }
    return ['--channel', options.channel, ...(options.stateRoot !== undefined ? ['--state-root', stateRoot] : []), ...(options.daemonArgs ?? [])];
}
/**
 * Connects to the daemon this client should work with, starting or replacing one as the rules
 * above say. Throws a `DaemonStartError` when it cannot.
 */
async function ensureNativeDaemon(options) {
    const stateRoot = options.stateRoot ?? (0, locate_1.nativeStateRoot)();
    const files = (0, locate_1.nativeChannelFiles)(stateRoot, options.channel);
    const host = options.host ?? (0, nativeLaunch_1.systemLaunchHost)();
    const channelHost = options.channelHost ?? (0, channel_1.systemChannelHost)();
    const readiness = options.readinessMs ?? exports.NATIVE_READINESS_MS;
    const args = channelArgs(options, stateRoot);
    const own = options.daemon ?? (options.kind === 'addon' ? (0, nativeLaunch_1.installedNativeLaunch)(files) : undefined);
    const buildKind = options.buildKind ?? options.daemon?.buildKind ?? 'release';
    const identity = { name: options.name, kind: options.kind, version: options.version, buildKind };
    const client = {
        kind: options.kind, buildKind, version: options.version, contractVersion: generated_1.CONTRACT_VERSION, canStart: own !== undefined,
    };
    const notice = (text) => { try {
        options.onNotice?.(text);
    }
    catch { /* the caller's own failure */ } };
    /** Finds a daemon; one that is there but not answering yet is tried again within the budget. */
    const find = async (until) => {
        for (;;) {
            try {
                return await (0, hello_1.connectNativeDaemon)({
                    files, client: identity, host: channelHost, acceptOtherContract: true,
                    ...(options.keyHost ? { keyHost: options.keyHost } : {}),
                });
            }
            catch (error) {
                if (!isUnavailable(error) || Date.now() >= until) {
                    throw error;
                }
                await sleep(100);
            }
        }
    };
    /** Whether a daemon serves the channel now. */
    const channelPresent = async () => {
        try {
            const channel = await (0, channel_1.openNativeChannel)(files, channelHost);
            if (channel.kind === 'none') {
                return false;
            }
            channel.stream.destroy();
            return true;
        }
        catch {
            return true;
        }
    };
    /** Waits until no daemon holds the channel. */
    const waitGone = async () => {
        const until = Date.now() + readiness;
        while (Date.now() < until) {
            try {
                const channel = await (0, channel_1.openNativeChannel)(files, channelHost);
                if (channel.kind === 'none') {
                    return;
                }
                channel.stream.destroy();
            }
            catch { /* ending: its pipe no longer answers */ }
            await sleep(100);
        }
        throw new nativeLaunch_1.DaemonStartError('lock_held', `The cockpit daemon was asked to exit but still held its channel after ${Math.round(readiness / 1000)} s.`);
    };
    /** Starts this client's verified copy and connects to whichever daemon then serves the channel. */
    const start = async (launch) => {
        const until = Date.now() + readiness;
        let binary = await (0, nativeLaunch_1.verifiedCopy)(launch, stateRoot, host);
        let child = host.spawn(binary, args, stateRoot);
        let lockHeldSince;
        let delay = 50;
        for (;;) {
            const outcome = child.outcome();
            if (outcome) {
                const failure = (0, nativeLaunch_1.classifyStartFailure)(outcome, binary, host, path.join(files.dir, 'daemon.log'));
                // Another daemon starts or ends on this channel: its channel shows up, or the lock frees.
                if (failure.failure !== 'lock_held') {
                    throw failure;
                }
                lockHeldSince ??= Date.now();
                if (Date.now() - lockHeldSince >= RESPAWN_AFTER_MS && Date.now() < until) {
                    binary = await (0, nativeLaunch_1.verifiedCopy)(launch, stateRoot, host);
                    child = host.spawn(binary, args, stateRoot);
                    lockHeldSince = undefined;
                }
            }
            const found = await find(0).catch((error) => {
                if (isUnavailable(error)) {
                    return { kind: 'none' };
                }
                throw error;
            });
            if (found.kind === 'connected') {
                return { connection: found, ours: found.record.pid === child.pid };
            }
            if (Date.now() >= until) {
                const failure = child.outcome();
                if (failure && (0, nativeLaunch_1.classifyStartFailure)(failure, binary, host, '').failure === 'lock_held') {
                    throw new nativeLaunch_1.DaemonStartError('lock_held', `Another cockpit daemon held this channel's lock and did not become reachable within ${Math.round(readiness / 1000)} s; try again.`);
                }
                throw new nativeLaunch_1.DaemonStartError('failed', `The cockpit daemon did not answer within ${Math.round(readiness / 1000)} s.`);
            }
            await sleep(delay);
            delay = Math.min(delay * 2, 250);
        }
    };
    const finish = (connection, started) => {
        try {
            (0, nativeLaunch_1.removeOldCopies)(stateRoot, [...(own ? [own.sha256] : []), connection.daemon.buildId]);
            // The installed cockpit records its daemon for add-ons; a development build is not the installed one.
            if (options.daemon?.buildKind === 'release' && (options.kind === 'vscode' || options.kind === 'cli')) {
                (0, nativeLaunch_1.recordNativeInstall)(files, options.daemon);
            }
        }
        catch { /* housekeeping only: the connection stands */ }
        return { endpoint: connection.endpoint, daemon: connection.daemon, record: connection.record, files, started };
    };
    let successorWait = options.successorWaitMs ?? 0;
    for (let round = 1; round <= MAX_ROUNDS; round++) {
        let found = await find(Date.now() + readiness);
        let started = false;
        if (found.kind === 'none') {
            if (successorWait > 0) {
                const until = Date.now() + successorWait;
                successorWait = 0;
                while (Date.now() < until && !(await channelPresent())) {
                    await sleep(100);
                }
                round--;
                continue;
            }
            if (!own) {
                throw new nativeLaunch_1.DaemonStartError('missing_binary', options.kind === 'addon'
                    ? 'No cockpit daemon runs and EVƎ Cockpit has not recorded one to start: install EVƎ Cockpit, or open VS Code with it once.'
                    : 'No cockpit daemon runs, and this client carries none to start.');
            }
            const result = await start(own);
            found = result.connection;
            started = result.ours;
        }
        const connection = found;
        if (connection.daemon.state === 'exiting') {
            connection.endpoint.close();
            await waitGone();
            continue;
        }
        const decision = started && connection.daemon.contractVersion === generated_1.CONTRACT_VERSION
            ? { action: 'use' }
            : decideOnDaemon(client, connection.daemon);
        if (decision.action === 'use') {
            if (decision.notice) {
                notice(decision.notice);
            }
            return finish(connection, started);
        }
        if (decision.action === 'stop') {
            connection.endpoint.close();
            throw new nativeLaunch_1.DaemonStartError('contract_mismatch', decision.reason);
        }
        const answer = await askToExit(connection.endpoint, options.exitAnswerMs ?? exports.EXIT_ANSWER_MS);
        if (answer.accepted) {
            connection.endpoint.close();
            await waitGone();
            continue;
        }
        const reason = answer.reason ?? 'The cockpit daemon refused to exit.';
        notice(reason);
        if (connection.daemon.contractVersion === generated_1.CONTRACT_VERSION) {
            return finish(connection, false);
        }
        connection.endpoint.close();
        throw new nativeLaunch_1.DaemonStartError('contract_mismatch', contractStop(connection.daemon, generated_1.CONTRACT_VERSION, reason));
    }
    throw new nativeLaunch_1.DaemonStartError('failed', 'The cockpit daemon kept changing while this client connected; try again.');
}
/**
 * Asks a daemon to exit and waits for its answer. A daemon that goes meanwhile counts as ending,
 * and so does one that cancelled the request: it does that only as it shuts down, when another
 * client's exit request came first.
 */
async function askToExit(endpoint, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
        return await endpoint.request('daemon/exit', {}, { signal: controller.signal });
    }
    catch (error) {
        if (controller.signal.aborted) {
            return { accepted: false, reason: `The cockpit daemon did not answer the exit request within ${Math.round(timeoutMs / 1000)} s.` };
        }
        if (isUnavailable(error)) {
            return { accepted: true };
        }
        if (error instanceof connection_1.ContractError && error.code === errors_1.WireErrorCode.Cancelled) {
            return { accepted: true };
        }
        return { accepted: false, reason: error instanceof Error ? error.message : String(error) };
    }
    finally {
        clearTimeout(timer);
    }
}
