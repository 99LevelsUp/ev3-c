/**
 * The client's side of the handshake: it sends its nonce, checks the daemon's proof before it says
 * anything more, and only then proves itself. A daemon that cannot prove it holds the user's key is
 * someone else's pipe; the client closes the connection and tells nothing.
 *
 * `connectNativeDaemon` finds the daemon, reads the key it created and runs the proofs with the
 * generated contract's hello messages.
 */
import type { BuildKind, ChannelRecord, DaemonMode } from '../contract/generated';
import { NativeChannelHost } from './channel';
import { Endpoint } from './connection';
import type { NativeChannelFiles } from './locate';
/** The native key is exactly this long. */
export declare const NATIVE_KEY_BYTES = 32;
/** How often a short or missing key is read before it counts as unreadable. */
export declare const KEY_READ_ATTEMPTS = 5;
/** A key that stayed short, missing or unreadable. Only the daemon creates the key; a client never touches it. */
export declare class KeyUnreadableError extends Error {
    constructor(message: string);
}
/** What reading the key needs; replaceable in tests. */
export interface KeyReadHost {
    readFile(file: string): Buffer;
    sleep(ms: number): Promise<void>;
}
/**
 * Reads the per-user key the native daemon created. The daemon writes it through a temporary file
 * and a link, so a short or missing read is momentary: it is read again a few times, then reported
 * as unreadable.
 */
export declare function readNativeKey(file: string, host?: KeyReadHost): Promise<Buffer>;
/** Who a client is in the native daemon's hello. */
export interface NativeClientIdentity {
    /** Where the client runs, as people read it in the daemon's log and in its messages. */
    readonly name: string;
    /** One of ClientKind, carried as a plain string. */
    readonly kind: string;
    /** The client's package version. */
    readonly version: string;
    /** One of BuildKind. */
    readonly buildKind: string;
}
/** Who the native daemon is, once it has proved it holds the key. */
export interface DaemonIdentity {
    readonly version: string;
    readonly contractVersion: number;
    readonly buildKind: BuildKind;
    /** SHA-256 of the daemon's executable, lowercase hex. */
    readonly buildId: string;
    readonly mode: DaemonMode;
    readonly pid: number;
    readonly instanceId: string;
    readonly state?: string;
    readonly transports?: readonly string[];
}
/**
 * The hello with the native daemon. The daemon's proof is checked before anything it says is
 * trusted, and before the client proves itself; a daemon on another contract version stops the
 * client instead of misbehaving.
 */
export declare function performNativeHello(endpoint: Endpoint, key: Buffer, client: NativeClientIdentity, options?: {
    readonly acceptOtherContract?: boolean;
}): Promise<DaemonIdentity>;
/** How long finding, opening and the hello may take before the client gives up. */
export declare const DEFAULT_CONNECT_TIMEOUT_MS = 10000;
export interface NativeConnectOptions {
    readonly files: NativeChannelFiles;
    readonly client: NativeClientIdentity;
    readonly host?: NativeChannelHost;
    readonly keyHost?: KeyReadHost;
    readonly timeoutMs?: number;
    /** Return a daemon on another contract version instead of refusing it, for the launch to decide. */
    readonly acceptOtherContract?: boolean;
}
export type NativeConnection = {
    readonly kind: 'none';
} | {
    readonly kind: 'connected';
    readonly endpoint: Endpoint;
    readonly daemon: DaemonIdentity;
    readonly record: ChannelRecord;
};
/**
 * Finds the native daemon, opens its channel and finishes the hello; or reports that no daemon
 * runs. Starting one is the caller's business. A daemon that does not finish the hello in time is
 * given up on and its connection closed, so a stuck daemon cannot hang the client.
 */
export declare function connectNativeDaemon(options: NativeConnectOptions): Promise<NativeConnection>;
