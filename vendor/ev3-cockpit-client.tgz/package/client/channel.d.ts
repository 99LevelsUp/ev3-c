/**
 * Which daemon a client talks to: the user's own, or a development or test daemon on a channel of
 * its own, so a development build never takes the user's daemon or its bricks. The VS Code
 * extension sets `EV3_COCKPIT_CHANNEL` in its Development and Test modes; the client library and
 * the `ev3` command honour it.
 *
 * Below that: how a client finds the native daemon. Only the daemon that holds the single-instance
 * lock writes `channel.json`, so a client connects only to the path recorded there and never
 * computes a pipe or socket name itself. A record whose daemon no longer holds the lock is deleted
 * and never contacted.
 */
import type { Duplex } from 'node:stream';
import type { ChannelRecord } from '../contract/generated';
import type { NativeChannelFiles } from './locate';
/** The environment variable that names a channel. */
export declare const CHANNEL_ENV = "EV3_COCKPIT_CHANNEL";
/** The channel the environment names, or undefined for the user's own daemon. */
export declare function channelFromEnv(env?: NodeJS.ProcessEnv): string | undefined;
/** The environment without a channel: what reaches the user's own daemon from inside a development one. */
export declare function withoutChannel(env?: NodeJS.ProcessEnv): NodeJS.ProcessEnv;
/** What finding the native daemon needs from the operating system; replaceable in tests. */
export interface NativeChannelHost {
    readonly platform: NodeJS.Platform;
    /** The user's id on Linux and macOS, which must own the socket directory. */
    readonly uid?: number;
    /**
     * Windows: opens the lock file for writing without creating or truncating it and returns what
     * closes it again. Throws the operating system's error: `EBUSY` or `EPERM` when the daemon holds
     * it with no sharing, `ENOENT` when there is none.
     */
    openLockForWriting(file: string): () => void;
    /** Linux and macOS: whether a process with this pid exists. */
    processAlive(pid: number): boolean;
    lstat(dir: string): {
        isDirectory(): boolean;
        isSymbolicLink(): boolean;
        readonly uid: number;
        readonly mode: number;
    };
    /** Connects to a pipe or socket path; rejects with the operating system's error. */
    connect(where: string): Promise<Duplex>;
}
export declare function systemChannelHost(): NativeChannelHost;
/** A `channel.json` as text, or undefined when it is not a usable record. Unknown properties are ignored. */
export declare function readChannelRecord(text: string): ChannelRecord | undefined;
export type NativeChannel = {
    readonly kind: 'none';
} | {
    readonly kind: 'open';
    readonly stream: Duplex;
    readonly record: ChannelRecord;
};
/**
 * Finds the native daemon and opens its pipe or socket, or reports that none runs.
 *
 * - No `channel.json`: no daemon.
 * - Windows: the daemon keeps the lock file open with no sharing. A client that can open it for
 *   writing knows no daemon holds it, and deletes the record while it still has the file open, so
 *   no daemon starting meanwhile can take the lock and write a record of its own in between.
 * - Linux and macOS: a dead pid, or a connect refused or missing, means the record is stale.
 *
 * A stale record is deleted and its path is never contacted.
 */
export declare function openNativeChannel(files: Pick<NativeChannelFiles, 'channelFile' | 'lockFile'>, host?: NativeChannelHost): Promise<NativeChannel>;
