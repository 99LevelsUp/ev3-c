"use strict";
/**
 * Which daemon a client talks to: the user's own, or a development or test daemon on a channel of
 * its own, so a development build never takes the user's daemon or its bricks. The VS Code
 * extension sets `EV3_COCKPIT_CHANNEL` in its Development and Test modes; the client library and
 * the `ev3` command honour it.
 *
 * Below that: how a client finds the native daemon. Only the daemon that holds the single-instance
 * lock writes `channel.json`, so a client connects only to the path recorded there and never
 * computes a pipe or socket name itself. A record whose daemon no longer holds the lock is deleted
 * and never contacted.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CHANNEL_ENV = void 0;
exports.channelFromEnv = channelFromEnv;
exports.withoutChannel = withoutChannel;
exports.systemChannelHost = systemChannelHost;
exports.readChannelRecord = readChannelRecord;
exports.openNativeChannel = openNativeChannel;
const fs = __importStar(require("node:fs"));
const net = __importStar(require("node:net"));
const path = __importStar(require("node:path"));
const errors_1 = require("../contract/errors");
const connection_1 = require("./connection");
/** The environment variable that names a channel. */
exports.CHANNEL_ENV = 'EV3_COCKPIT_CHANNEL';
/** The channel the environment names, or undefined for the user's own daemon. */
function channelFromEnv(env = process.env) {
    const channel = env[exports.CHANNEL_ENV]?.trim();
    return channel ? channel : undefined;
}
/** The environment without a channel: what reaches the user's own daemon from inside a development one. */
function withoutChannel(env = process.env) {
    const copy = { ...env };
    delete copy[exports.CHANNEL_ENV];
    return copy;
}
function systemChannelHost() {
    return {
        platform: process.platform,
        ...(typeof process.getuid === 'function' ? { uid: process.getuid() } : {}),
        openLockForWriting(file) {
            const handle = fs.openSync(file, 'r+');
            return () => fs.closeSync(handle);
        },
        processAlive(pid) {
            try {
                process.kill(pid, 0);
                return true;
            }
            catch (error) {
                // EPERM: the process exists, it is just not ours to signal.
                return error.code === 'EPERM';
            }
        },
        lstat: (dir) => fs.lstatSync(dir),
        connect: (where) => new Promise((resolve, reject) => {
            const socket = net.connect(where);
            const onError = (error) => { socket.destroy(); reject(error); };
            socket.once('error', onError);
            socket.once('connect', () => { socket.off('error', onError); resolve(socket); });
        }),
    };
}
/** A `channel.json` as text, or undefined when it is not a usable record. Unknown properties are ignored. */
function readChannelRecord(text) {
    let value;
    try {
        value = JSON.parse(text);
    }
    catch {
        return undefined;
    }
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        return undefined;
    }
    const { path: where, pid } = value;
    if (typeof where !== 'string' || where.length === 0) {
        return undefined;
    }
    if (typeof pid !== 'number' || !Number.isSafeInteger(pid) || pid <= 0) {
        return undefined;
    }
    return { path: where, pid };
}
const NONE = { kind: 'none' };
function readText(file) {
    try {
        return fs.readFileSync(file, 'utf8');
    }
    catch (error) {
        if (error.code === 'ENOENT') {
            return undefined;
        }
        throw error;
    }
}
/**
 * Deletes a stale record, unless it changed since it was judged stale: a daemon that started
 * meanwhile has written its own, and that one stays.
 */
function deleteStale(file, judged) {
    if (readText(file) !== judged) {
        return;
    }
    try {
        fs.unlinkSync(file);
    }
    catch (error) {
        if (error.code !== 'ENOENT') {
            throw error;
        }
    }
}
function errorCode(error) {
    return error?.code;
}
function unavailable(message) {
    return new connection_1.ContractError(errors_1.WireErrorCode.DaemonUnavailable, message);
}
/** Refuses a socket directory anyone but the user could have put a socket in. */
function checkSocketDir(socketPath, host) {
    const dir = path.posix.dirname(socketPath);
    let stat;
    try {
        stat = host.lstat(dir);
    }
    catch (error) {
        throw unavailable(`The cockpit daemon's socket directory ${dir} cannot be checked (${errorCode(error) ?? String(error)}); the client did not connect.`);
    }
    if (!stat.isDirectory() || stat.isSymbolicLink()) {
        throw unavailable(`The cockpit daemon's socket directory ${dir} is not a plain directory; the client did not connect.`);
    }
    if (host.uid !== undefined && stat.uid !== host.uid) {
        throw unavailable(`The cockpit daemon's socket directory ${dir} belongs to another user; the client did not connect.`);
    }
    if ((stat.mode & 0o077) !== 0) {
        throw unavailable(`The cockpit daemon's socket directory ${dir} can be opened by other users (mode ${(stat.mode & 0o777).toString(8)}); the client did not connect.`);
    }
}
/**
 * Finds the native daemon and opens its pipe or socket, or reports that none runs.
 *
 * - No `channel.json`: no daemon.
 * - Windows: the daemon keeps the lock file open with no sharing. A client that can open it for
 *   writing knows no daemon holds it, and deletes the record while it still has the file open, so
 *   no daemon starting meanwhile can take the lock and write a record of its own in between.
 * - Linux and macOS: a dead pid, or a connect refused or missing, means the record is stale.
 *
 * A stale record is deleted and its path is never contacted.
 */
async function openNativeChannel(files, host = systemChannelHost()) {
    const text = readText(files.channelFile);
    if (text === undefined) {
        return NONE;
    }
    const record = readChannelRecord(text);
    if (host.platform === 'win32') {
        let close;
        try {
            close = host.openLockForWriting(files.lockFile);
        }
        catch (error) {
            const code = errorCode(error);
            if (code === 'ENOENT') {
                deleteStale(files.channelFile, text);
                return NONE;
            }
            if (code !== 'EBUSY' && code !== 'EPERM') {
                throw error;
            }
        }
        if (close) {
            try {
                deleteStale(files.channelFile, text);
            }
            finally {
                close();
            }
            return NONE;
        }
        if (!record) {
            throw unavailable(`A cockpit daemon runs, but its channel record ${files.channelFile} cannot be read.`);
        }
        try {
            return { kind: 'open', stream: await host.connect(record.path), record };
        }
        catch (error) {
            throw unavailable(`The cockpit daemon (pid ${record.pid}) runs but is not answering on ${record.path} (${errorCode(error) ?? String(error)}).`);
        }
    }
    if (!record || !host.processAlive(record.pid)) {
        deleteStale(files.channelFile, text);
        return NONE;
    }
    checkSocketDir(record.path, host);
    try {
        return { kind: 'open', stream: await host.connect(record.path), record };
    }
    catch (error) {
        const code = errorCode(error);
        if (code === 'ENOENT' || code === 'ECONNREFUSED') {
            deleteStale(files.channelFile, text);
            return NONE;
        }
        throw unavailable(`The cockpit daemon (pid ${record.pid}) is not answering on ${record.path} (${code ?? String(error)}).`);
    }
}
