/**
 * The proofs of the hello: each side shows it holds the user's key with an HMAC over both nonces,
 * labelled by who proves. `docs/channel.md` is the written rule; the daemon computes the same.
 */
/** A fresh nonce, hex. */
export declare function newNonce(): string;
export declare function daemonProof(key: Buffer, clientNonce: string, daemonNonce: string): string;
export declare function clientProof(key: Buffer, clientNonce: string, daemonNonce: string): string;
/** Compares two hex proofs in constant time. */
export declare function proofsMatch(expected: string, given: unknown): boolean;
