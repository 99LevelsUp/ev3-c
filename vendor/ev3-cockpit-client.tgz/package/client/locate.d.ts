/**
 * Where this user's daemon keeps its state and channel files, from a client's side.
 */
export interface NativeRootInputs {
    readonly platform?: NodeJS.Platform;
    readonly env?: Readonly<Record<string, string | undefined>>;
    readonly homedir?: string;
}
/**
 * The native daemon's state root: the platform's state directory, then `ev3-cockpit/native`.
 * Windows `%LOCALAPPDATA%`, macOS `~/Library/Application Support`, Linux `$XDG_STATE_HOME` or
 * `~/.local/state`.
 */
export declare function nativeStateRoot(inputs?: NativeRootInputs): string;
/** The files a client reads to find and prove itself to one native daemon. */
export interface NativeChannelFiles {
    /** The channel's directory: the state root, or `channels/<name>/` in it for a test channel. */
    readonly dir: string;
    /** The per-user key, shared by every channel. Only the daemon creates it. */
    readonly keyFile: string;
    /** Held by the daemon, exclusively, for its whole life. */
    readonly lockFile: string;
    /** Where the lock holder records its pipe or socket path and its pid. */
    readonly channelFile: string;
}
/** The native daemon's files under `root`, for the user's own daemon or a named test channel. */
export declare function nativeChannelFiles(root: string, channel?: string): NativeChannelFiles;
