/**
 * The client of the native daemon, on the generated contract: what the VS Code extension, the
 * `ev3` command, the MCP server and add-ons use once they move to the native daemon.
 *
 * - It finds this user's daemon, starts or replaces it as `nativeDaemon.ts` says, and proves both
 *   sides hold the user's key.
 * - It keeps the bricks, the settings and the access mode current from the daemon's notifications.
 * - When the daemon goes (a crash, a restart, a replacement) it connects again, to the successor
 *   when one is on its way, else to a daemon it starts. Nothing is handed over between daemons:
 *   it connects its own bricks again and renews its subscriptions, each with a fresh snapshot.
 *   Bricks held with `ev3 connect` the new daemon connects itself.
 * - Questions for a person go to the handler the caller set, with who asked; without a handler the
 *   answer is `keep`, which the daemon reads as unanswered.
 */
import type { AccessMode, BuildKind, ClientKind, ContractBrick, ContractChain, LaunchSpec, MethodName, NotificationName, Notifications, ParamsOf, ProgramState, Question, QuestionAnswer, QuestionReply, ResultOf, SettingValue, TelemetryRequest, TelemetryUpdate } from '../contract/generated';
import type { NativeChannelHost } from './channel';
import { RequestOptions } from './connection';
import type { DaemonIdentity, KeyReadHost } from './hello';
import type { LaunchHost } from './nativeLaunch';
/** After its daemon went, how long the client waits for a successor before it starts one itself. */
export declare const SUCCESSOR_WAIT_MS = 3000;
export interface Disposable {
    dispose(): void;
}
/** What the question handler is told besides the question: the signal aborts when it is withdrawn. */
export interface QuestionContext {
    readonly signal: AbortSignal;
}
/** Answers a question for a person; `remember` applies a yes or no to this client's own later requests. */
export type QuestionHandler = (question: Question, context: QuestionContext) => QuestionReply | QuestionAnswer | Promise<QuestionReply | QuestionAnswer>;
export interface CockpitClientOptions {
    /** Shown in the daemon's log, in other clients' `brick_busy` and in questions: say where this client runs. */
    readonly name: string;
    readonly kind: ClientKind;
    /** This client's package version. */
    readonly version: string;
    /** This client's build kind; by default its daemon's, else `release`. */
    readonly buildKind?: BuildKind;
    /** The daemon this client carries (`packagedDaemon`, `developmentDaemon`); an add-on carries none. */
    readonly daemon?: LaunchSpec;
    /** A test channel, and a state root of its own for it. */
    readonly channel?: string;
    readonly stateRoot?: string;
    /** More arguments for a daemon started on a test channel: replay and its recording. */
    readonly daemonArgs?: readonly string[];
    readonly readinessMs?: number;
    /** Reconnect when the daemon goes (default true). */
    readonly reconnect?: boolean;
    readonly host?: LaunchHost;
    readonly channelHost?: NativeChannelHost;
    readonly keyHost?: KeyReadHost;
}
type Listener<T> = (value: T) => void;
export declare class CockpitClient {
    private readonly options;
    private connection;
    private disposed;
    private brickList;
    private settingList;
    private access;
    private active;
    private questionHandler;
    private readonly openQuestions;
    private readonly renewables;
    /** Subscriptions a reconnect could not renew, because their brick was not back yet. */
    private readonly unrenewed;
    /** Bricks this client connected for itself, without a hold: connected again on a new daemon. */
    private readonly myBricks;
    private readonly notificationHandlers;
    private nextId;
    private reconnecting;
    private renewing;
    private bounces;
    private readonly bricksChanged;
    private readonly reconnected;
    private readonly notices;
    private readonly lost;
    /** The bricks changed. */
    readonly onBricksChanged: (listener: Listener<readonly ContractBrick[]>) => Disposable;
    /** Connected again after the previous daemon went; own bricks and subscriptions are back. */
    readonly onReconnected: (listener: Listener<DaemonIdentity>) => Disposable;
    /** Something the user should know: a development daemon runs, an exit request was refused. */
    readonly onNotice: (listener: Listener<string>) => Disposable;
    /** The daemon went and could not be reached again. */
    readonly onLost: (listener: Listener<Error>) => Disposable;
    private constructor();
    /** Connects, starting or replacing the daemon as needed; a start failure is a `DaemonStartError`. */
    static connect(options: CockpitClientOptions, onNotice?: Listener<string>): Promise<CockpitClient>;
    /** Who the daemon said it is when this client connected. */
    get daemon(): DaemonIdentity;
    /** The bricks as last heard; no round trip. */
    bricks(): readonly ContractBrick[];
    brick(ref: string): ContractBrick | undefined;
    settings(): readonly SettingValue[];
    accessMode(): AccessMode;
    /** This client's active brick, whose telemetry the daemon reads in the foreground. */
    activeBrick(): string | undefined;
    setActiveBrick(brickId: string | undefined): Promise<void>;
    /**
     * Who answers the daemon's questions for a person. The question names who asked
     * (`question.requester`, name and kind, where the kind has one). Without a handler every answer
     * is `keep`, which the daemon reads as unanswered.
     */
    onQuestion(handler: QuestionHandler | undefined): void;
    request<M extends MethodName>(method: M, params: ParamsOf<M>, options?: RequestOptions): Promise<ResultOf<M>>;
    /** Hears one notification; survives reconnects. */
    on<N extends NotificationName>(name: N, handler: (params: Notifications[N]) => void): Disposable;
    /**
     * One subscription that survives reconnects: `open` makes it (again after a reconnect),
     * `opened` hears its first answer each time, `changed` every notification for it after that.
     * The daemon may send a notification for the new subscription before its answer arrives; those
     * are held while it opens and handed on, in order, right after `opened`.
     */
    private follow;
    /** A brick's program state, now and on every change, across reconnects. */
    subscribePrograms(brick: string, listener: Listener<ProgramState>): Promise<Disposable & {
        readonly state: ProgramState;
    }>;
    /** Telemetry of a brick: a snapshot first, then changes; again a snapshot after every reconnect. */
    subscribeTelemetry(brick: string, request: TelemetryRequest, listener: Listener<TelemetryUpdate>): Promise<Disposable & {
        readonly grant: ResultOf<'telemetry/subscribe'>['grant'];
    }>;
    /** The daisy chain below a brick, now and on every change. */
    followChain(brick: string, listener: Listener<ContractChain>): Promise<Disposable>;
    dispose(): void;
    private cancel;
    private open;
    private answer;
    /** Tries the subscriptions a reconnect could not renew again, one round at a time. */
    private renewPending;
    private dispatch;
    private connectAgain;
}
export {};
