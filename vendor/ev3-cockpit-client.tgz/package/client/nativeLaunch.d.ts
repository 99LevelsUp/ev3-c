/**
 * Starting the native daemon from a client. A client never starts the binary it carries: it copies
 * it into the user's state root, checks the copy's SHA-256, and starts exactly that copy.
 *
 * - The copy goes to `bin/<sha256>/` under the state root, through a unique temporary file renamed
 *   into place. Each such directory holds only the binary. `bin/` and `bin/<sha256>/` must be the
 *   user's alone: on Linux and macOS a plain directory of the user's that nobody else can open, on
 *   Windows a directory whose access list lets in nobody but the user, SYSTEM and the
 *   Administrators. The client gives the directories it creates an owner-only access list.
 * - The copy is hashed, not the source. A copy that verifies is reused; one that does not is
 *   replaced. A binary whose copy does not match the SHA-256 its package recorded is refused.
 * - The installed file is never started, so it is never locked: `npm i -g` and a rebuild work
 *   while a daemon runs. The copy starts with the state root as its working directory.
 * - Clients remove the copies other than their own and the running daemon's, skipping locked ones
 *   and ones used in the last minutes, which another client may be about to start.
 * - Where the binary comes from: a packaged client reads the manifest its package carries beside
 *   the binary; a development client reads the one a build step writes after each `cargo build`
 *   (`npm run daemon:build`). Nothing in the environment changes either location.
 * - On Windows a start that fails (a spawn error, or an exit with a code the daemon never uses) is
 *   read as Smart App Control when the code-integrity policy reports it on or in evaluation. Node
 *   reports such a block only as `spawn UNKNOWN`. A daemon that exited with one of its own codes
 *   ran, so it was not blocked.
 */
import type { LaunchSpec } from '../contract/generated';
import { ContractError } from './connection';
import type { NativeChannelFiles } from './locate';
/** The file beside the binary that records its SHA-256, version and build kind. */
export declare const DAEMON_MANIFEST = "ev3-cockpitd.manifest.json";
/** The daemon executable's file name. */
export declare function daemonBinaryName(platform?: NodeJS.Platform): string;
/**
 * Why a client could not start or use the daemon. Every client tells them apart the same way and
 * shows them its own way.
 *
 * - `missing_binary`: no daemon to start (nothing carried, the file gone, no install record).
 * - `sha_mismatch`: the binary does not match the SHA-256 its package or build step recorded.
 * - `not_private`: the directory of the verified copies is not the user's alone.
 * - `smart_app_control`: Windows Smart App Control blocked the unsigned binary.
 * - `name_held`: the daemon refused to run (exit code 3), for example because someone else holds
 *   its pipe or socket name; the message carries the end of its log.
 * - `lock_held`: another daemon held the channel's lock (exit code 2) and none became reachable.
 * - `contract_mismatch`: the running daemon speaks another contract and could not be replaced.
 * - `failed`: anything else, with the exit code and the end of the log.
 */
export type StartFailure = 'missing_binary' | 'sha_mismatch' | 'not_private' | 'smart_app_control' | 'name_held' | 'lock_held' | 'contract_mismatch' | 'failed';
/** A start failure. Its contract code is `daemon_unavailable`, so code-based handling keeps working. */
export declare class DaemonStartError extends ContractError {
    readonly failure: StartFailure;
    constructor(failure: StartFailure, message: string);
}
/** A launch record as JSON reads it, or undefined when it is not one. */
export declare function readLaunchSpec(value: unknown): LaunchSpec | undefined;
/**
 * The daemon a packaged client carries: the binary in `dir` (the package's own directory, which the
 * caller derives from where its code lies) and the manifest the package carries beside it.
 */
export declare function packagedDaemon(dir: string): LaunchSpec;
/** The Cargo profiles a development build may come from. */
export type CargoProfile = 'debug' | 'release';
/**
 * The daemon a development client runs: `daemon/target/<profile>/` of the repository, with the
 * manifest `npm run daemon:build` writes after each build. Without a profile, the build whose
 * manifest was written last.
 */
export declare function developmentDaemon(repoRoot: string, profile?: CargoProfile): LaunchSpec;
/** What a directory looks like to the checks; the parts of `fs.Stats` they read. */
export interface DirStat {
    isDirectory(): boolean;
    isSymbolicLink(): boolean;
    readonly uid: number;
    readonly mode: number;
}
/** How a started daemon ended before it answered, if it did. */
export type SpawnOutcome = {
    readonly kind: 'exit';
    readonly code: number | null;
    readonly signal: string | null;
} | {
    readonly kind: 'error';
    readonly error: NodeJS.ErrnoException;
};
export interface SpawnedDaemon {
    readonly pid: number | undefined;
    /** How the process ended, or undefined while it runs. */
    outcome(): SpawnOutcome | undefined;
}
/** What starting the daemon needs from the operating system; replaceable in tests. */
export interface LaunchHost {
    readonly platform: NodeJS.Platform;
    /** The user's id on Linux and macOS. */
    readonly uid?: number;
    lstat(target: string): DirStat;
    /** Windows: gives a directory a protected access list with the user alone. */
    restrictToUser(dir: string): void;
    /** Windows: who besides the user, SYSTEM and the Administrators the directory's access list lets in. */
    othersWithAccess(dir: string): string[];
    /** Starts the daemon detached, so it outlives this client. */
    spawn(file: string, args: readonly string[], cwd: string): SpawnedDaemon;
    /** Windows: `VerifiedAndReputablePolicyState` (0 off, 1 on, 2 evaluation), or undefined when unreadable. */
    smartAppControlPolicy(): number | undefined;
}
/** The SIDs other than `me`, SYSTEM and the Administrators that the allow entries of a DACL in SDDL name. */
export declare function othersInSddl(sddl: string, me: string): string[];
export declare function systemLaunchHost(): LaunchHost;
/** Refuses a copy directory anyone but the user could put a file in. */
export declare function checkPrivateDir(dir: string, host: LaunchHost): void;
/**
 * Makes `dir` as a private directory unless it exists, then checks it. A new directory is made
 * private under a temporary name and renamed into place, so another client never sees it half done.
 */
export declare function ensurePrivateDir(dir: string, host: LaunchHost): void;
/** The SHA-256 of a file, lowercase hex, or undefined when it is not there. */
export declare function hashFile(file: string): Promise<string | undefined>;
/**
 * The verified copy of `launch.binary` under `stateRoot`: reused when it hashes to
 * `launch.sha256`, else copied again. Refuses a binary whose copy does not match.
 */
export declare function verifiedCopy(launch: LaunchSpec, stateRoot: string, host: LaunchHost): Promise<string>;
/** A copy folder touched this recently may be about to start: clean-up leaves it. */
export declare const RECENT_COPY_MS: number;
/**
 * Removes the verified copies other than `keep` (SHA-256 values). A locked one stays, and so does
 * one used in the last minutes: another client may be copying it or about to start it.
 */
export declare function removeOldCopies(stateRoot: string, keep: readonly string[]): void;
/** Where a channel's install record is: the add-on launch record. */
export declare function nativeInstallFile(files: Pick<NativeChannelFiles, 'dir'>): string;
/** Records the installed cockpit's daemon, so an add-on can start it; written whole or not at all. */
export declare function recordNativeInstall(files: Pick<NativeChannelFiles, 'dir'>, launch: LaunchSpec): void;
/** The installed cockpit's daemon, as its VS Code extension or `ev3` command recorded it. */
export declare function installedNativeLaunch(files: Pick<NativeChannelFiles, 'dir'>): LaunchSpec | undefined;
/**
 * Why a started daemon ended before it answered.
 *
 * - Error 4551, the code-integrity violation itself, as an error or an exit code: Smart App
 *   Control, whatever the policy says.
 * - One of the daemon's own exit codes: it ran, so it was not blocked; read by the code and the end
 *   of its log, never as Smart App Control.
 * - On Windows anything else (a spawn error with any code, or an exit with a code the daemon never
 *   uses) is Smart App Control when the policy reads on or in evaluation.
 */
export declare function classifyStartFailure(outcome: SpawnOutcome, binary: string, host: LaunchHost, logFile: string): DaemonStartError;
