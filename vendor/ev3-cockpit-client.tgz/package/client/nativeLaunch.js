"use strict";
/**
 * Starting the native daemon from a client. A client never starts the binary it carries: it copies
 * it into the user's state root, checks the copy's SHA-256, and starts exactly that copy.
 *
 * - The copy goes to `bin/<sha256>/` under the state root, through a unique temporary file renamed
 *   into place. Each such directory holds only the binary. `bin/` and `bin/<sha256>/` must be the
 *   user's alone: on Linux and macOS a plain directory of the user's that nobody else can open, on
 *   Windows a directory whose access list lets in nobody but the user, SYSTEM and the
 *   Administrators. The client gives the directories it creates an owner-only access list.
 * - The copy is hashed, not the source. A copy that verifies is reused; one that does not is
 *   replaced. A binary whose copy does not match the SHA-256 its package recorded is refused.
 * - The installed file is never started, so it is never locked: `npm i -g` and a rebuild work
 *   while a daemon runs. The copy starts with the state root as its working directory.
 * - Clients remove the copies other than their own and the running daemon's, skipping locked ones
 *   and ones used in the last minutes, which another client may be about to start.
 * - Where the binary comes from: a packaged client reads the manifest its package carries beside
 *   the binary; a development client reads the one a build step writes after each `cargo build`
 *   (`npm run daemon:build`). Nothing in the environment changes either location.
 * - On Windows a start that fails (a spawn error, or an exit with a code the daemon never uses) is
 *   read as Smart App Control when the code-integrity policy reports it on or in evaluation. Node
 *   reports such a block only as `spawn UNKNOWN`. A daemon that exited with one of its own codes
 *   ran, so it was not blocked.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.RECENT_COPY_MS = exports.DaemonStartError = exports.DAEMON_MANIFEST = void 0;
exports.daemonBinaryName = daemonBinaryName;
exports.readLaunchSpec = readLaunchSpec;
exports.packagedDaemon = packagedDaemon;
exports.developmentDaemon = developmentDaemon;
exports.othersInSddl = othersInSddl;
exports.systemLaunchHost = systemLaunchHost;
exports.checkPrivateDir = checkPrivateDir;
exports.ensurePrivateDir = ensurePrivateDir;
exports.hashFile = hashFile;
exports.verifiedCopy = verifiedCopy;
exports.removeOldCopies = removeOldCopies;
exports.nativeInstallFile = nativeInstallFile;
exports.recordNativeInstall = recordNativeInstall;
exports.installedNativeLaunch = installedNativeLaunch;
exports.classifyStartFailure = classifyStartFailure;
const node_child_process_1 = require("node:child_process");
const node_crypto_1 = require("node:crypto");
const fs = __importStar(require("node:fs"));
const os = __importStar(require("node:os"));
const path = __importStar(require("node:path"));
const errors_1 = require("../contract/errors");
const connection_1 = require("./connection");
/** The file beside the binary that records its SHA-256, version and build kind. */
exports.DAEMON_MANIFEST = 'ev3-cockpitd.manifest.json';
/** The daemon executable's file name. */
function daemonBinaryName(platform = process.platform) {
    return platform === 'win32' ? 'ev3-cockpitd.exe' : 'ev3-cockpitd';
}
/** A start failure. Its contract code is `daemon_unavailable`, so code-based handling keeps working. */
class DaemonStartError extends connection_1.ContractError {
    failure;
    constructor(failure, message) {
        super(errors_1.WireErrorCode.DaemonUnavailable, message);
        this.name = 'DaemonStartError';
        this.failure = failure;
    }
}
exports.DaemonStartError = DaemonStartError;
const SHA256 = /^[0-9a-f]{64}$/;
/** A launch record as JSON reads it, or undefined when it is not one. */
function readLaunchSpec(value) {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        return undefined;
    }
    const { binary, sha256, version, buildKind } = value;
    if (typeof binary !== 'string' || !path.isAbsolute(binary)) {
        return undefined;
    }
    if (typeof sha256 !== 'string' || !SHA256.test(sha256)) {
        return undefined;
    }
    if (typeof version !== 'string' || version.length === 0) {
        return undefined;
    }
    if (buildKind !== 'release' && buildKind !== 'development') {
        return undefined;
    }
    return { binary, sha256, version, buildKind };
}
function readJson(file) {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
}
/** The manifest in `dir` as a launch, the binary beside it; `hint` says how to get a good one. */
function manifestLaunch(dir, hint) {
    const file = path.join(dir, exports.DAEMON_MANIFEST);
    let manifest;
    try {
        manifest = readJson(file);
    }
    catch (error) {
        const code = error.code;
        throw new DaemonStartError('missing_binary', code === 'ENOENT'
            ? `The cockpit daemon's manifest ${file} is missing. ${hint}`
            : `The cockpit daemon's manifest ${file} cannot be read (${code ?? String(error)}). ${hint}`);
    }
    const name = manifest?.binary;
    // The binary is named by its file name alone: a manifest never points out of its directory.
    const launch = typeof name === 'string' && name.length > 0 && path.basename(name) === name && name !== '.' && name !== '..'
        ? readLaunchSpec({ ...manifest, binary: path.join(dir, name) })
        : undefined;
    if (!launch) {
        throw new DaemonStartError('missing_binary', `The cockpit daemon's manifest ${file} is not valid. ${hint}`);
    }
    if (!fs.existsSync(launch.binary)) {
        throw new DaemonStartError('missing_binary', `The cockpit daemon ${launch.binary} is missing. ${hint}`);
    }
    return launch;
}
/**
 * The daemon a packaged client carries: the binary in `dir` (the package's own directory, which the
 * caller derives from where its code lies) and the manifest the package carries beside it.
 */
function packagedDaemon(dir) {
    return manifestLaunch(dir, 'Reinstall EVƎ Cockpit.');
}
/**
 * The daemon a development client runs: `daemon/target/<profile>/` of the repository, with the
 * manifest `npm run daemon:build` writes after each build. Without a profile, the build whose
 * manifest was written last.
 */
function developmentDaemon(repoRoot, profile) {
    const hint = 'Build it with npm run daemon:build.';
    const profiles = profile ? [profile] : ['debug', 'release'];
    const dirs = profiles.map((p) => path.join(repoRoot, 'daemon', 'target', p));
    const written = (dir) => {
        try {
            return fs.statSync(path.join(dir, exports.DAEMON_MANIFEST)).mtimeMs;
        }
        catch {
            return -1;
        }
    };
    const newest = dirs.reduce((best, dir) => (written(dir) > written(best) ? dir : best), dirs[0]);
    if (written(newest) < 0) {
        throw new DaemonStartError('missing_binary', `No development build of the cockpit daemon in ${path.join(repoRoot, 'daemon', 'target')}. ${hint}`);
    }
    return manifestLaunch(newest, hint);
}
/** A Windows system tool by its full path, never found through the current directory. */
function systemTool(name) {
    return path.win32.join(process.env.SystemRoot || process.env.windir || 'C:\\Windows', 'System32', `${name}.exe`);
}
function runTool(name, args) {
    const run = (0, node_child_process_1.spawnSync)(systemTool(name), args, { encoding: 'utf8', windowsHide: true, timeout: 15_000 });
    if (run.error) {
        throw run.error;
    }
    if (run.status !== 0) {
        throw new Error(`${name} failed: ${(run.stderr || run.stdout || '').trim()}`);
    }
    return run.stdout;
}
let userSid;
/** The current user's SID, read once from `whoami`. */
function currentUserSid() {
    if (userSid) {
        return userSid;
    }
    const sid = /"(S-1-[0-9-]+)"\s*$/.exec(runTool('whoami', ['/user', '/fo', 'csv', '/nh']).trim())?.[1];
    if (!sid) {
        throw new Error('The current user\'s SID could not be read from whoami.');
    }
    userSid = sid;
    return sid;
}
/** SDDL names of the accounts that may reach any user's files anyway. */
const TRUSTED_SDDL = new Set(['SY', 'S-1-5-18', 'BA', 'S-1-5-32-544']);
/** The SIDs other than `me`, SYSTEM and the Administrators that the allow entries of a DACL in SDDL name. */
function othersInSddl(sddl, me) {
    const dacl = /D:[A-Z]*((?:\([^)]*\))*)/.exec(sddl)?.[1] ?? '';
    const others = [];
    for (const [, ace] of dacl.matchAll(/\(([^)]*)\)/g)) {
        const fields = ace.split(';');
        const type = fields[0];
        const sid = fields[5] ?? '';
        if (type !== 'A' && type !== 'OA') {
            continue;
        }
        if (sid === me || TRUSTED_SDDL.has(sid)) {
            continue;
        }
        others.push(sid);
    }
    return others;
}
class ProcessDaemon {
    child;
    ended;
    constructor(child) {
        this.child = child;
        child.once('exit', (code, signal) => { this.ended ??= { kind: 'exit', code, signal }; });
        child.once('error', (error) => { this.ended ??= { kind: 'error', error }; });
        child.unref();
    }
    get pid() { return this.child.pid; }
    outcome() { return this.ended; }
}
function systemLaunchHost() {
    return {
        platform: process.platform,
        ...(typeof process.getuid === 'function' ? { uid: process.getuid() } : {}),
        lstat: (target) => fs.lstatSync(target),
        restrictToUser(dir) {
            runTool('icacls', [dir, '/inheritance:r', '/grant:r', `*${currentUserSid()}:(OI)(CI)F`, '/q']);
        },
        othersWithAccess(dir) {
            // icacls prints account names in the system's language; its saved form is SDDL, with SIDs.
            const saved = path.join(os.tmpdir(), `ev3-cockpit-acl-${(0, node_crypto_1.randomBytes)(6).toString('hex')}.txt`);
            try {
                runTool('icacls', [dir, '/save', saved, '/q']);
                return othersInSddl(fs.readFileSync(saved, 'utf16le'), currentUserSid());
            }
            finally {
                fs.rmSync(saved, { force: true });
            }
        },
        spawn: (file, args, cwd) => new ProcessDaemon((0, node_child_process_1.spawn)(file, [...args], {
            cwd, detached: true, stdio: 'ignore', windowsHide: true,
        })),
        smartAppControlPolicy() {
            try {
                const out = runTool('reg', ['query', 'HKLM\\SYSTEM\\CurrentControlSet\\Control\\CI\\Policy', '/v', 'VerifiedAndReputablePolicyState']);
                const value = /VerifiedAndReputablePolicyState\s+REG_DWORD\s+0x([0-9a-f]+)/i.exec(out)?.[1];
                return value === undefined ? undefined : Number.parseInt(value, 16);
            }
            catch {
                return undefined;
            }
        },
    };
}
function notPrivate(dir, why) {
    return new DaemonStartError('not_private', `The folder of the cockpit daemon's verified copies ${dir} ${why}; the daemon was not started from it.`);
}
/** Refuses a copy directory anyone but the user could put a file in. */
function checkPrivateDir(dir, host) {
    let stat;
    try {
        stat = host.lstat(dir);
    }
    catch (error) {
        throw notPrivate(dir, `cannot be checked (${error.code ?? String(error)})`);
    }
    if (!stat.isDirectory() || stat.isSymbolicLink()) {
        throw notPrivate(dir, 'is not a plain folder');
    }
    if (host.platform === 'win32') {
        let others;
        try {
            others = host.othersWithAccess(dir);
        }
        catch (error) {
            throw notPrivate(dir, `cannot be checked (${error instanceof Error ? error.message : String(error)})`);
        }
        if (others.length > 0) {
            throw notPrivate(dir, `can be reached by others (${others.join(', ')})`);
        }
        return;
    }
    if (host.uid !== undefined && stat.uid !== host.uid) {
        throw notPrivate(dir, 'belongs to another user');
    }
    if ((stat.mode & 0o077) !== 0) {
        throw notPrivate(dir, `can be opened by other users (mode ${(stat.mode & 0o777).toString(8)})`);
    }
}
/**
 * Makes `dir` as a private directory unless it exists, then checks it. A new directory is made
 * private under a temporary name and renamed into place, so another client never sees it half done.
 */
function ensurePrivateDir(dir, host) {
    if (!fs.existsSync(dir)) {
        const fresh = path.join(path.dirname(dir), `.new-${(0, node_crypto_1.randomBytes)(6).toString('hex')}`);
        fs.mkdirSync(fresh, { mode: 0o700 });
        try {
            if (host.platform === 'win32') {
                host.restrictToUser(fresh);
            }
            else {
                fs.chmodSync(fresh, 0o700);
            }
            fs.renameSync(fresh, dir);
        }
        catch {
            // Another client made it meanwhile; its directory is checked below like any other.
        }
        finally {
            fs.rmSync(fresh, { recursive: true, force: true });
        }
    }
    checkPrivateDir(dir, host);
}
/** The SHA-256 of a file, lowercase hex, or undefined when it is not there. */
async function hashFile(file) {
    try {
        const hash = (0, node_crypto_1.createHash)('sha256');
        for await (const chunk of fs.createReadStream(file)) {
            hash.update(chunk);
        }
        return hash.digest('hex');
    }
    catch (error) {
        if (error.code === 'ENOENT') {
            return undefined;
        }
        throw error;
    }
}
/** Windows refuses to replace a file that runs or is open without sharing. */
const REPLACE_REFUSED = new Set(['EPERM', 'EACCES', 'EBUSY', 'EEXIST', 'ENOTEMPTY']);
/**
 * The verified copy of `launch.binary` under `stateRoot`: reused when it hashes to
 * `launch.sha256`, else copied again. Refuses a binary whose copy does not match.
 */
async function verifiedCopy(launch, stateRoot, host) {
    if (!SHA256.test(launch.sha256)) {
        throw new DaemonStartError('sha_mismatch', `The SHA-256 recorded for the cockpit daemon ${launch.binary} is not valid; it was not started.`);
    }
    fs.mkdirSync(stateRoot, { recursive: true, mode: 0o700 });
    const bin = path.join(stateRoot, 'bin');
    const dir = path.join(bin, launch.sha256);
    const target = path.join(dir, daemonBinaryName(host.platform));
    for (let attempt = 0; attempt < 3; attempt++) {
        // In every round: another client's clean-up may have removed the folder meanwhile.
        ensurePrivateDir(bin, host);
        ensurePrivateDir(dir, host);
        if (await hashFile(target) === launch.sha256) {
            markInUse(dir);
            return target;
        }
        if (!fs.existsSync(launch.binary)) {
            throw new DaemonStartError('missing_binary', `The cockpit daemon ${launch.binary} is missing.`);
        }
        const temp = path.join(dir, `.${(0, node_crypto_1.randomBytes)(8).toString('hex')}.tmp`);
        try {
            await fs.promises.copyFile(launch.binary, temp, fs.constants.COPYFILE_EXCL);
            if (host.platform !== 'win32') {
                await fs.promises.chmod(temp, 0o700);
            }
            const copied = await hashFile(temp);
            // Gone before it was hashed: removed by another client's clean-up, not a mismatch. Copy again.
            if (copied === undefined) {
                continue;
            }
            if (copied !== launch.sha256) {
                const hint = launch.buildKind === 'development'
                    ? 'Rebuild it with npm run daemon:build, which writes its manifest again.'
                    : 'Reinstall EVƎ Cockpit.';
                throw new DaemonStartError('sha_mismatch', `The cockpit daemon ${launch.binary} does not match the SHA-256 its package recorded: it is ${copied}, the package says ${launch.sha256}. It was not started. ${hint}`);
            }
            await fs.promises.rename(temp, target);
        }
        catch (error) {
            if (error instanceof DaemonStartError) {
                throw error;
            }
            // The folder went meanwhile, or another client placed the copy, or it runs: the next round checks.
            const code = error.code ?? '';
            if (code !== 'ENOENT' && !REPLACE_REFUSED.has(code)) {
                throw error;
            }
        }
        finally {
            await fs.promises.rm(temp, { force: true });
        }
    }
    throw new DaemonStartError('failed', `The verified copy of the cockpit daemon could not be placed in ${dir}.`);
}
/** A copy folder touched this recently may be about to start: clean-up leaves it. */
exports.RECENT_COPY_MS = 10 * 60_000;
/** Marks a verified copy as just used, so no other client's clean-up removes it before it starts. */
function markInUse(dir) {
    try {
        const now = new Date();
        fs.utimesSync(dir, now, now);
    }
    catch { /* only a guard for the clean-up */ }
}
/**
 * Removes the verified copies other than `keep` (SHA-256 values). A locked one stays, and so does
 * one used in the last minutes: another client may be copying it or about to start it.
 */
function removeOldCopies(stateRoot, keep) {
    const bin = path.join(stateRoot, 'bin');
    let entries;
    try {
        entries = fs.readdirSync(bin);
    }
    catch {
        return;
    }
    for (const entry of entries) {
        if (!SHA256.test(entry) || keep.includes(entry)) {
            continue;
        }
        const dir = path.join(bin, entry);
        try {
            if (Date.now() - fs.statSync(dir).mtimeMs < exports.RECENT_COPY_MS) {
                continue;
            }
            for (const file of fs.readdirSync(dir)) {
                fs.unlinkSync(path.join(dir, file));
            }
            fs.rmdirSync(dir);
        }
        catch {
            // Locked: a daemon still runs from it. The next client tries again.
        }
    }
}
/** Where a channel's install record is: the add-on launch record. */
function nativeInstallFile(files) {
    return path.join(files.dir, 'install.json');
}
/** Records the installed cockpit's daemon, so an add-on can start it; written whole or not at all. */
function recordNativeInstall(files, launch) {
    const file = nativeInstallFile(files);
    const text = `${JSON.stringify({ binary: launch.binary, sha256: launch.sha256, version: launch.version, buildKind: launch.buildKind }, null, 2)}\n`;
    try {
        if (fs.readFileSync(file, 'utf8') === text) {
            return;
        }
    }
    catch { /* not there yet */ }
    fs.mkdirSync(files.dir, { recursive: true, mode: 0o700 });
    const temp = `${file}.${(0, node_crypto_1.randomBytes)(6).toString('hex')}.tmp`;
    try {
        fs.writeFileSync(temp, text, { mode: 0o600, flag: 'wx' });
        fs.renameSync(temp, file);
    }
    finally {
        fs.rmSync(temp, { force: true });
    }
}
/** The installed cockpit's daemon, as its VS Code extension or `ev3` command recorded it. */
function installedNativeLaunch(files) {
    try {
        const launch = readLaunchSpec(readJson(nativeInstallFile(files)));
        return launch && fs.existsSync(launch.binary) ? launch : undefined;
    }
    catch {
        return undefined;
    }
}
/** The Windows error a code-integrity policy raises when it blocks an executable. */
const ERROR_SYSTEM_INTEGRITY_POLICY_VIOLATION = 4551;
function isIntegrityViolation(outcome) {
    if (outcome.kind === 'exit') {
        return outcome.code === ERROR_SYSTEM_INTEGRITY_POLICY_VIOLATION;
    }
    const { errno, message } = outcome.error;
    return errno === ERROR_SYSTEM_INTEGRITY_POLICY_VIOLATION || errno === -ERROR_SYSTEM_INTEGRITY_POLICY_VIOLATION
        || /\b4551\b/.test(message ?? '');
}
function endedHow(outcome) {
    if (outcome.kind === 'error') {
        return `it could not be started (${outcome.error.code ?? outcome.error.message})`;
    }
    return outcome.signal ? `it ended on ${outcome.signal}` : `it exited with code ${String(outcome.code)}`;
}
function logTail(file, lines = 12) {
    try {
        const text = fs.readFileSync(file, 'utf8').trimEnd();
        return text ? `\nIts log ${file} ends:\n${text.split('\n').slice(-lines).join('\n')}` : '';
    }
    catch {
        return '';
    }
}
/** The daemon's exit codes that mean it ran and decided to stop. */
const LOCK_HELD = 2;
const REFUSED = 3;
/**
 * Every exit code the daemon documents: 0 a clean end, 1 a failure, 2 the lock held, 3 a refusal
 * to run, 64 a command line it did not understand. A process that exited with one of them ran.
 */
const DAEMON_EXIT_CODES = [0, 1, LOCK_HELD, REFUSED, 64];
/**
 * Why a started daemon ended before it answered.
 *
 * - Error 4551, the code-integrity violation itself, as an error or an exit code: Smart App
 *   Control, whatever the policy says.
 * - One of the daemon's own exit codes: it ran, so it was not blocked; read by the code and the end
 *   of its log, never as Smart App Control.
 * - On Windows anything else (a spawn error with any code, or an exit with a code the daemon never
 *   uses) is Smart App Control when the policy reads on or in evaluation.
 */
function classifyStartFailure(outcome, binary, host, logFile) {
    const blocked = () => new DaemonStartError('smart_app_control', `Windows Smart App Control blocked the EVƎ Cockpit daemon (${binary}). Smart App Control lets only signed or well-known apps run, and the cockpit's daemon is not signed yet, so the cockpit cannot run on this computer while Smart App Control is on.`);
    if (host.platform === 'win32' && isIntegrityViolation(outcome)) {
        return blocked();
    }
    if (outcome.kind === 'exit' && outcome.code === LOCK_HELD) {
        return new DaemonStartError('lock_held', `Another cockpit daemon holds this channel's lock while it starts or ends; ${binary} stopped.`);
    }
    if (outcome.kind === 'exit' && outcome.code === REFUSED) {
        return new DaemonStartError('name_held', `The cockpit daemon refused to run: its pipe or socket name may be held by someone else, or it was started with administrator or root rights.${logTail(logFile)}`);
    }
    const ran = outcome.kind === 'exit' && outcome.code !== null && DAEMON_EXIT_CODES.includes(outcome.code);
    if (host.platform === 'win32' && !ran) {
        const policy = host.smartAppControlPolicy();
        if (policy === 1 || policy === 2) {
            return blocked();
        }
    }
    return new DaemonStartError('failed', `The cockpit daemon could not start: ${endedHow(outcome)}.${logTail(logFile)}`);
}
