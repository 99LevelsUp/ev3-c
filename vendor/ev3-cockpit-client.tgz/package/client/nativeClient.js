"use strict";
/**
 * The client of the native daemon, on the generated contract: what the VS Code extension, the
 * `ev3` command, the MCP server and add-ons use once they move to the native daemon.
 *
 * - It finds this user's daemon, starts or replaces it as `nativeDaemon.ts` says, and proves both
 *   sides hold the user's key.
 * - It keeps the bricks, the settings and the access mode current from the daemon's notifications.
 * - When the daemon goes (a crash, a restart, a replacement) it connects again, to the successor
 *   when one is on its way, else to a daemon it starts. Nothing is handed over between daemons:
 *   it connects its own bricks again and renews its subscriptions, each with a fresh snapshot.
 *   Bricks held with `ev3 connect` the new daemon connects itself.
 * - Questions for a person go to the handler the caller set, with who asked; without a handler the
 *   answer is `keep`, which the daemon reads as unanswered.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CockpitClient = exports.SUCCESSOR_WAIT_MS = void 0;
const errors_1 = require("../contract/errors");
const generated_1 = require("../contract/generated");
const connection_1 = require("./connection");
const nativeDaemon_1 = require("./nativeDaemon");
/** How often in a row a daemon may go away during the reconnect to it before the client gives up. */
const MAX_BOUNCES = 3;
/** The wait before the next of those reconnects, times how many came before it. */
const BOUNCE_DELAY_MS = 500;
/** After its daemon went, how long the client waits for a successor before it starts one itself. */
exports.SUCCESSOR_WAIT_MS = 3_000;
function safely(call) {
    try {
        call();
    }
    catch { /* a listener's own failure */ }
}
class Emitter {
    listeners = new Set();
    on(listener) {
        this.listeners.add(listener);
        return { dispose: () => this.listeners.delete(listener) };
    }
    fire(value) {
        for (const listener of [...this.listeners]) {
            safely(() => listener(value));
        }
    }
}
const NOTIFICATIONS = [
    'bricks/changed', 'bricks/reconnected', 'bricks/pairingStarted', 'bricks/pairingEvent', 'bricks/pairingDone',
    'bricks/oneSidedRepair', 'programs/stateChanged', 'telemetry/update', 'chain/changed', 'settings/changed',
    'settings/accessModeChanged', 'question/withdrawn', 'daemon/showsChanged',
];
const ANSWERS = ['yes', 'no', 'keep'];
/** A handler's answer as the wire carries it; anything unusable reads as `keep`. */
function toReply(answer) {
    if (typeof answer === 'string') {
        return { answer: ANSWERS.includes(answer) ? answer : 'keep' };
    }
    if (!answer || !ANSWERS.includes(answer.answer)) {
        return { answer: 'keep' };
    }
    return answer.remember === undefined ? { answer: answer.answer } : { answer: answer.answer, remember: answer.remember };
}
class CockpitClient {
    options;
    connection;
    disposed = false;
    brickList = [];
    settingList = [];
    access = 'safe';
    active;
    questionHandler;
    openQuestions = new Map();
    renewables = new Map();
    /** Subscriptions a reconnect could not renew, because their brick was not back yet. */
    unrenewed = new Set();
    /** Bricks this client connected for itself, without a hold: connected again on a new daemon. */
    myBricks = new Set();
    notificationHandlers = new Map();
    nextId = 0;
    reconnecting;
    renewing = false;
    bounces = 0;
    bricksChanged = new Emitter();
    reconnected = new Emitter();
    notices = new Emitter();
    lost = new Emitter();
    /** The bricks changed. */
    onBricksChanged = (listener) => this.bricksChanged.on(listener);
    /** Connected again after the previous daemon went; own bricks and subscriptions are back. */
    onReconnected = (listener) => this.reconnected.on(listener);
    /** Something the user should know: a development daemon runs, an exit request was refused. */
    onNotice = (listener) => this.notices.on(listener);
    /** The daemon went and could not be reached again. */
    onLost = (listener) => this.lost.on(listener);
    constructor(options) {
        this.options = options;
    }
    /** Connects, starting or replacing the daemon as needed; a start failure is a `DaemonStartError`. */
    static async connect(options, onNotice) {
        const client = new CockpitClient(options);
        if (onNotice) {
            client.onNotice(onNotice);
        }
        try {
            await client.open(0);
        }
        catch (error) {
            // The caller never gets this client: it must not stay connected, or reconnect on its own
            // when the daemon closes a connection whose first requests failed.
            client.dispose();
            throw error;
        }
        return client;
    }
    /** Who the daemon said it is when this client connected. */
    get daemon() { return this.connection.daemon; }
    /** The bricks as last heard; no round trip. */
    bricks() { return this.brickList; }
    brick(ref) {
        const wanted = ref.trim().toLowerCase();
        return this.brickList.find((b) => b.brickId === ref) ?? this.brickList.find((b) => b.name.trim().toLowerCase() === wanted);
    }
    settings() { return this.settingList; }
    accessMode() { return this.access; }
    /** This client's active brick, whose telemetry the daemon reads in the foreground. */
    activeBrick() { return this.active; }
    async setActiveBrick(brickId) {
        this.active = brickId;
        await this.request('telemetry/foreground', brickId === undefined ? {} : { brick: brickId });
    }
    /**
     * Who answers the daemon's questions for a person. The question names who asked
     * (`question.requester`, name and kind, where the kind has one). Without a handler every answer
     * is `keep`, which the daemon reads as unanswered.
     */
    onQuestion(handler) {
        this.questionHandler = handler;
    }
    async request(method, params, options) {
        const endpoint = this.connection.endpoint;
        const sent = !endpoint.closed;
        let result;
        try {
            result = await endpoint.request(method, params, options);
        }
        catch (error) {
            // A write cut off by the daemon going may or may not have happened; it is never retried.
            if (sent && error instanceof connection_1.ContractError && error.code === errors_1.WireErrorCode.DaemonUnavailable && generated_1.METHODS[method].leased) {
                throw new connection_1.ContractError(errors_1.WireErrorCode.OutcomeUnknown, `The cockpit daemon went while ${method} ran, so whether it finished is not known. It was not retried.`);
            }
            throw error;
        }
        if (method === 'bricks/connect') {
            const p = params;
            if (!p.hold) {
                this.myBricks.add(result.brickId);
            }
        }
        else if (method === 'bricks/disconnect') {
            const p = params;
            const id = p.brick ? this.brick(p.brick)?.brickId ?? p.brick : undefined;
            if (id && !p.releaseHold) {
                this.myBricks.delete(id);
            }
        }
        return result;
    }
    /** Hears one notification; survives reconnects. */
    on(name, handler) {
        let set = this.notificationHandlers.get(name);
        if (!set) {
            set = new Set();
            this.notificationHandlers.set(name, set);
        }
        const wrapped = handler;
        set.add(wrapped);
        return { dispose: () => set.delete(wrapped) };
    }
    /**
     * One subscription that survives reconnects: `open` makes it (again after a reconnect),
     * `opened` hears its first answer each time, `changed` every notification for it after that.
     * The daemon may send a notification for the new subscription before its answer arrives; those
     * are held while it opens and handed on, in order, right after `opened`.
     */
    async follow(name, open, opened, changed) {
        const id = `s${++this.nextId}`;
        let current;
        let held;
        let first;
        const renew = async () => {
            held = [];
            try {
                const result = await open();
                const renewed = first !== undefined;
                first ??= result;
                opened(result, id, renewed);
                current = result.subscriptionId;
                for (const params of held) {
                    if (params.subscriptionId === current) {
                        changed(params, id);
                    }
                }
                return result.subscriptionId;
            }
            finally {
                held = undefined;
            }
        };
        const off = this.on(name, (params) => {
            if (held) {
                held.push(params);
                return;
            }
            if (params.subscriptionId === current) {
                changed(params, id);
            }
        });
        try {
            const wireId = await renew();
            this.renewables.set(id, { wireId, renew });
        }
        catch (error) {
            off.dispose();
            throw error;
        }
        return { first: first, dispose: () => { off.dispose(); this.cancel(id); } };
    }
    /** A brick's program state, now and on every change, across reconnects. */
    async subscribePrograms(brick, listener) {
        const { first, dispose } = await this.follow('programs/stateChanged', () => this.request('programs/subscribe', { brick }), (result, _id, renewed) => { if (renewed) {
            safely(() => listener(result.state));
        } }, (p) => listener(p.state));
        return { state: first.state, dispose };
    }
    /** Telemetry of a brick: a snapshot first, then changes; again a snapshot after every reconnect. */
    async subscribeTelemetry(brick, request, listener) {
        const { first, dispose } = await this.follow('telemetry/update', () => this.request('telemetry/subscribe', { brick, request }), (result, id) => safely(() => listener({ subscriptionId: id, brickId: result.brickId, kind: 'snapshot', values: result.snapshot, removed: [] })), (u, id) => listener({ ...u, subscriptionId: id }));
        return { grant: first.grant, dispose };
    }
    /** The daisy chain below a brick, now and on every change. */
    async followChain(brick, listener) {
        const { dispose } = await this.follow('chain/changed', () => this.request('chain/follow', { brick }), (result) => safely(() => listener(result.chain)), (c) => listener(c.chain));
        return { dispose };
    }
    dispose() {
        this.disposed = true;
        this.renewables.clear();
        this.unrenewed.clear();
        this.connection?.endpoint.close();
    }
    cancel(id) {
        const renewable = this.renewables.get(id);
        if (!renewable) {
            return;
        }
        this.renewables.delete(id);
        this.unrenewed.delete(id);
        if (!this.connection.endpoint.closed) {
            void this.request('subscriptions/cancel', { subscriptionId: renewable.wireId }).catch(() => undefined);
        }
    }
    async open(successorWaitMs) {
        const o = this.options;
        const connection = await (0, nativeDaemon_1.ensureNativeDaemon)({
            name: o.name, kind: o.kind, version: o.version, successorWaitMs,
            onNotice: (text) => this.notices.fire(text),
            ...(o.buildKind ? { buildKind: o.buildKind } : {}),
            ...(o.daemon ? { daemon: o.daemon } : {}),
            ...(o.channel ? { channel: o.channel } : {}),
            ...(o.stateRoot !== undefined ? { stateRoot: o.stateRoot } : {}),
            ...(o.daemonArgs ? { daemonArgs: o.daemonArgs } : {}),
            ...(o.readinessMs ? { readinessMs: o.readinessMs } : {}),
            ...(o.host ? { host: o.host } : {}),
            ...(o.channelHost ? { channelHost: o.channelHost } : {}),
            ...(o.keyHost ? { keyHost: o.keyHost } : {}),
        });
        // Disposed while this connection was being made: it must not stay open.
        if (this.disposed) {
            connection.endpoint.close();
            throw new connection_1.ContractError(errors_1.WireErrorCode.DaemonUnavailable, 'The client was disposed while it connected.');
        }
        this.connection = connection;
        const { endpoint } = connection;
        endpoint.onRequest('question/ask', async (params, context) => this.answer(params, context.signal));
        for (const name of NOTIFICATIONS) {
            endpoint.onNotification(name, (params) => this.dispatch(name, params));
        }
        // A connection that closes before its first lists came is a failed open, which the caller
        // hears about; only one that opened fully is reconnected when it closes.
        let opened = false;
        endpoint.onClose(() => {
            for (const controller of this.openQuestions.values()) {
                controller.abort();
            }
            this.openQuestions.clear();
            if (opened) {
                void this.connectAgain();
            }
        });
        const [bricks, settings, access] = await Promise.all([
            this.request('bricks/list', {}), this.request('settings/list', {}), this.request('settings/accessMode', {}),
        ]);
        this.brickList = [...bricks.bricks];
        this.settingList = [...settings.settings];
        this.access = access.mode;
        opened = true;
        if (endpoint.closed) {
            void this.connectAgain();
        }
        if (this.active) {
            await this.request('telemetry/foreground', { brick: this.active }).catch(() => undefined);
        }
    }
    async answer(question, signal) {
        const handler = this.questionHandler;
        if (!handler) {
            return { answer: 'keep' };
        }
        const controller = new AbortController();
        const abort = () => controller.abort();
        signal.addEventListener('abort', abort, { once: true });
        this.openQuestions.set(question.questionId, controller);
        try {
            return toReply(await handler(question, { signal: controller.signal }));
        }
        catch {
            return { answer: 'keep' };
        }
        finally {
            signal.removeEventListener('abort', abort);
            this.openQuestions.delete(question.questionId);
        }
    }
    /** Tries the subscriptions a reconnect could not renew again, one round at a time. */
    async renewPending() {
        if (this.renewing || this.reconnecting || this.unrenewed.size === 0 || this.connection.endpoint.closed) {
            return;
        }
        this.renewing = true;
        try {
            for (const id of [...this.unrenewed]) {
                const renewable = this.renewables.get(id);
                if (!renewable) {
                    this.unrenewed.delete(id);
                    continue;
                }
                try {
                    renewable.wireId = await renewable.renew();
                    this.unrenewed.delete(id);
                }
                catch { /* still not back: the next change of the bricks tries again */ }
            }
        }
        finally {
            this.renewing = false;
        }
    }
    dispatch(name, params) {
        if (name === 'bricks/reconnected') {
            void this.renewPending();
        }
        if (name === 'bricks/changed') {
            void this.renewPending();
            this.brickList = [...params.bricks];
            this.bricksChanged.fire(this.brickList);
        }
        else if (name === 'settings/changed') {
            const { setting } = params;
            this.settingList = this.settingList.map((s) => (s.spec.key === setting.spec.key ? setting : s));
        }
        else if (name === 'settings/accessModeChanged') {
            this.access = params.mode;
        }
        else if (name === 'question/withdrawn') {
            this.openQuestions.get(params.questionId)?.abort();
        }
        for (const handler of [...(this.notificationHandlers.get(name) ?? [])]) {
            safely(() => handler(params));
        }
    }
    connectAgain() {
        if (this.disposed || this.options.reconnect === false) {
            return Promise.resolve();
        }
        this.reconnecting ??= (async () => {
            const before = this.connection;
            try {
                // A replacement's successor is on its way: wait for it before starting a daemon here.
                await this.open(exports.SUCCESSOR_WAIT_MS);
                // No daemon hands anything to the next: this client's own bricks are connected again.
                for (const brickId of [...this.myBricks]) {
                    await this.connection.endpoint.request('bricks/connect', { brick: brickId }).catch(() => undefined);
                }
                for (const [id, renewable] of this.renewables) {
                    try {
                        renewable.wireId = await renewable.renew();
                        this.unrenewed.delete(id);
                    }
                    catch {
                        this.unrenewed.add(id);
                    }
                }
                if (!this.connection.endpoint.closed) {
                    this.reconnected.fire(this.connection.daemon);
                }
            }
            catch (error) {
                if (!this.disposed) {
                    this.lost.fire(error instanceof Error ? error : new connection_1.ContractError(errors_1.WireErrorCode.DaemonUnavailable, String(error)));
                }
            }
            finally {
                this.reconnecting = undefined;
            }
            // The daemon just reached went again during the reconnect: go round once more, a few times only.
            if (!this.disposed && this.connection !== before && this.connection.endpoint.closed) {
                if (++this.bounces > MAX_BOUNCES) {
                    this.bounces = 0;
                    this.lost.fire(new connection_1.ContractError(errors_1.WireErrorCode.DaemonUnavailable, 'The cockpit daemon kept going away right after this client reached it.'));
                    return;
                }
                await new Promise((resolve) => setTimeout(resolve, BOUNCE_DELAY_MS * this.bounces));
                await this.connectAgain();
                return;
            }
            this.bounces = 0;
            if (!this.disposed && !this.connection.endpoint.closed) {
                void this.renewPending();
            }
        })();
        return this.reconnecting;
    }
}
exports.CockpitClient = CockpitClient;
