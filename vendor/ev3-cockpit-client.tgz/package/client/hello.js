"use strict";
/**
 * The client's side of the handshake: it sends its nonce, checks the daemon's proof before it says
 * anything more, and only then proves itself. A daemon that cannot prove it holds the user's key is
 * someone else's pipe; the client closes the connection and tells nothing.
 *
 * `connectNativeDaemon` finds the daemon, reads the key it created and runs the proofs with the
 * generated contract's hello messages.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_CONNECT_TIMEOUT_MS = exports.KeyUnreadableError = exports.KEY_READ_ATTEMPTS = exports.NATIVE_KEY_BYTES = void 0;
exports.readNativeKey = readNativeKey;
exports.performNativeHello = performNativeHello;
exports.connectNativeDaemon = connectNativeDaemon;
const errors_1 = require("../contract/errors");
const proofs_1 = require("./proofs");
const generated_1 = require("../contract/generated");
const fs = __importStar(require("node:fs"));
const channel_1 = require("./channel");
const connection_1 = require("./connection");
/** The native key is exactly this long. */
exports.NATIVE_KEY_BYTES = 32;
/** How often a short or missing key is read before it counts as unreadable. */
exports.KEY_READ_ATTEMPTS = 5;
const KEY_RETRY_MS = 20;
/** A key that stayed short, missing or unreadable. Only the daemon creates the key; a client never touches it. */
class KeyUnreadableError extends Error {
    constructor(message) {
        super(message);
        this.name = 'KeyUnreadableError';
    }
}
exports.KeyUnreadableError = KeyUnreadableError;
const systemKeyReadHost = {
    readFile: (file) => fs.readFileSync(file),
    sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
};
/**
 * Reads the per-user key the native daemon created. The daemon writes it through a temporary file
 * and a link, so a short or missing read is momentary: it is read again a few times, then reported
 * as unreadable.
 */
async function readNativeKey(file, host = systemKeyReadHost) {
    let problem = '';
    for (let attempt = 1; attempt <= exports.KEY_READ_ATTEMPTS; attempt++) {
        try {
            const key = host.readFile(file);
            if (key.length === exports.NATIVE_KEY_BYTES) {
                return key;
            }
            problem = `it has ${key.length} bytes instead of ${exports.NATIVE_KEY_BYTES}`;
        }
        catch (error) {
            const code = error.code;
            if (code !== 'ENOENT') {
                throw new KeyUnreadableError(`The cockpit key ${file} could not be read (${code ?? String(error)}).`);
            }
            problem = 'it is not there';
        }
        if (attempt < exports.KEY_READ_ATTEMPTS) {
            await host.sleep(KEY_RETRY_MS);
        }
    }
    throw new KeyUnreadableError(`The cockpit key ${file} could not be read: ${problem}.`);
}
/**
 * The hello with the native daemon. The daemon's proof is checked before anything it says is
 * trusted, and before the client proves itself; a daemon on another contract version stops the
 * client instead of misbehaving.
 */
async function performNativeHello(endpoint, key, client, options = {}) {
    const clientNonce = (0, proofs_1.newNonce)();
    const start = {
        clientNonce, clientName: client.name, clientKind: client.kind, version: client.version,
        contractVersion: generated_1.CONTRACT_VERSION, buildKind: client.buildKind,
    };
    const challenge = await endpoint.request(generated_1.HELLO_START, start);
    const daemonNonce = challenge?.daemonNonce;
    if (typeof daemonNonce !== 'string' || !(0, proofs_1.proofsMatch)((0, proofs_1.daemonProof)(key, clientNonce, daemonNonce), challenge?.daemonProof)) {
        endpoint.close();
        throw new connection_1.ContractError(errors_1.WireErrorCode.DaemonUnavailable, 'The process on the cockpit channel could not prove it is your cockpit daemon; nothing was sent to it.');
    }
    const finish = { clientProof: (0, proofs_1.clientProof)(key, clientNonce, daemonNonce) };
    const accepted = await endpoint.request(generated_1.HELLO_FINISH, finish);
    if (typeof accepted?.contractVersion !== 'number' || typeof accepted.version !== 'string') {
        endpoint.close();
        throw new connection_1.ContractError(errors_1.WireErrorCode.DaemonUnavailable, 'The cockpit daemon did not say which version it is; the connection was closed.');
    }
    // A daemon on another contract still serves daemon/exit; the launch decides whether to ask it.
    if (accepted.contractVersion !== generated_1.CONTRACT_VERSION && !options.acceptOtherContract) {
        endpoint.close();
        throw new connection_1.ContractError(errors_1.WireErrorCode.DaemonUnavailable, `The running cockpit daemon speaks contract ${String(accepted?.contractVersion)} and this client contract ${generated_1.CONTRACT_VERSION}; update the older of the two.`);
    }
    return {
        version: accepted.version,
        contractVersion: accepted.contractVersion,
        buildKind: (0, generated_1.readBuildKind)(accepted.buildKind),
        buildId: accepted.buildId,
        mode: (0, generated_1.readDaemonMode)(accepted.mode),
        pid: accepted.pid,
        instanceId: accepted.instanceId,
        ...(accepted.state !== undefined ? { state: accepted.state } : {}),
        ...(accepted.transports !== undefined ? { transports: accepted.transports } : {}),
    };
}
/** How long finding, opening and the hello may take before the client gives up. */
exports.DEFAULT_CONNECT_TIMEOUT_MS = 10_000;
/**
 * Finds the native daemon, opens its channel and finishes the hello; or reports that no daemon
 * runs. Starting one is the caller's business. A daemon that does not finish the hello in time is
 * given up on and its connection closed, so a stuck daemon cannot hang the client.
 */
async function connectNativeDaemon(options) {
    const host = options.host ?? (0, channel_1.systemChannelHost)();
    const timeoutMs = options.timeoutMs ?? exports.DEFAULT_CONNECT_TIMEOUT_MS;
    let timedOut = false;
    let endpoint;
    let stream;
    let timer;
    const deadline = new Promise((_resolve, reject) => {
        timer = setTimeout(() => {
            timedOut = true;
            endpoint?.close();
            stream?.destroy();
            reject(new connection_1.ContractError(errors_1.WireErrorCode.DaemonUnavailable, `The cockpit daemon did not finish the hello within ${timeoutMs} ms; the connection was closed.`));
        }, timeoutMs);
    });
    const attempt = async () => {
        const channel = await (0, channel_1.openNativeChannel)(options.files, host);
        if (channel.kind === 'none') {
            return channel;
        }
        stream = channel.stream;
        if (timedOut) {
            channel.stream.destroy();
            return { kind: 'none' };
        }
        let key;
        try {
            key = await readNativeKey(options.files.keyFile, options.keyHost);
        }
        catch (error) {
            channel.stream.destroy();
            throw error;
        }
        endpoint = (0, connection_1.createEndpoint)(channel.stream);
        const daemon = await performNativeHello(endpoint, key, options.client, options.acceptOtherContract ? { acceptOtherContract: true } : {});
        return { kind: 'connected', endpoint, daemon, record: channel.record };
    };
    try {
        return await Promise.race([attempt(), deadline]);
    }
    catch (error) {
        endpoint?.close();
        stream?.destroy();
        throw error;
    }
    finally {
        clearTimeout(timer);
    }
}
