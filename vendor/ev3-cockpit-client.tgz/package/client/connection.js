"use strict";
/**
 * One end of a contract connection: JSON-RPC 2.0 framed the way LSP frames it, over any duplex
 * stream — a named pipe, a unix socket, or a pair of streams in a test.
 *
 * Built on `vscode-jsonrpc`, with three things it does not do on its own:
 * - when the stream closes, every pending request fails with `daemon_unavailable` instead of
 *   waiting forever: at once when this side closes, and when the other side ends the stream, right
 *   after the answers and notifications it sent before the end have been handled;
 * - a message larger than the cap closes the connection, so a broken or hostile peer cannot make
 *   this process buffer without limit;
 * - a cancelled request is answered with the contract's own `cancelled` error.
 *
 * Both the daemon and its clients use it.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContractError = exports.DEFAULT_MAX_MESSAGE_BYTES = void 0;
exports.needsPerson = needsPerson;
exports.createEndpoint = createEndpoint;
const node_stream_1 = require("node:stream");
const node_1 = require("vscode-jsonrpc/node");
const errors_1 = require("../contract/errors");
const generated_1 = require("../contract/generated");
/** A message larger than this closes the connection. */
exports.DEFAULT_MAX_MESSAGE_BYTES = 1024 * 1024;
/** An error that crossed the wire, or one this side raises with a contract code. */
/** A refusal a person can lift: `command` is what they can run. */
function needsPerson(message, command) {
    return new ContractError(errors_1.WireErrorCode.NeedsPerson, message, { command });
}
/**
 * A contract error: decide on `code`. `data` is the contract's `ErrorData` — the code, its family,
 * and `holder`, `candidates` or `command` where the code has them.
 */
class ContractError extends Error {
    code;
    data;
    constructor(code, message, extra = {}) {
        super(message);
        this.name = 'ContractError';
        this.code = code;
        // The family the daemon sent stands: a newer daemon's code may not be in this client's table.
        this.data = { ...extra, code, family: extra.family ?? generated_1.ERROR_FAMILY[code] };
    }
}
exports.ContractError = ContractError;
/** This side's own marker, queued behind the last message the other side sent before it ended. */
const DRAINED = '$/ev3-cockpit/drained';
const DRAINED_BODY = JSON.stringify({ jsonrpc: '2.0', method: DRAINED });
const DRAINED_FRAME = Buffer.from(`Content-Length: ${Buffer.byteLength(DRAINED_BODY)}\r\n\r\n${DRAINED_BODY}`, 'utf8');
/** The parameter a progress-reporting request carries its token in. */
const PROGRESS_TOKEN = '__progressToken';
const PROGRESS = new node_1.ProgressType();
/**
 * Passes framed messages through and closes the stream on one whose declared length is over the
 * cap, before its body is read.
 */
class FrameGuard extends node_stream_1.Transform {
    max;
    onOversize;
    header = '';
    bodyLeft = 0;
    constructor(max, onOversize) {
        super();
        this.max = max;
        this.onOversize = onOversize;
    }
    _transform(chunk, _encoding, done) {
        let offset = 0;
        while (offset < chunk.length) {
            if (this.bodyLeft > 0) {
                const take = Math.min(this.bodyLeft, chunk.length - offset);
                this.push(chunk.subarray(offset, offset + take));
                this.bodyLeft -= take;
                offset += take;
                continue;
            }
            const end = chunk.indexOf('\r\n\r\n', offset, 'latin1');
            const slice = chunk.subarray(offset, end < 0 ? chunk.length : end + 4);
            this.header += slice.toString('latin1');
            offset += slice.length;
            if (end < 0) {
                if (this.header.length > 8192) {
                    done(new Error('a message header was too long'));
                    return;
                }
                continue;
            }
            const match = /Content-Length:\s*(\d+)/i.exec(this.header);
            const length = match ? Number(match[1]) : Number.NaN;
            if (!Number.isFinite(length)) {
                done(new Error('a message had no length'));
                return;
            }
            if (length > this.max) {
                this.onOversize(length);
                done(new Error(`a message of ${length} bytes is over the ${this.max}-byte limit`));
                return;
            }
            this.push(Buffer.from(this.header, 'latin1'));
            this.header = '';
            this.bodyLeft = length;
        }
        done();
    }
    /**
     * The stream ended: the drain marker goes last, so the reader decodes it after every message
     * before it. A stream that ended inside a message has nothing more to drain; it says so instead.
     */
    _flush(done) {
        if (this.bodyLeft > 0 || this.header.length > 0) {
            this.emit('truncated');
        }
        else {
            this.push(DRAINED_FRAME);
        }
        done();
    }
}
/** The error a handler's failure becomes on the wire. */
function toResponseError(error) {
    if (error instanceof node_1.ResponseError) {
        return error;
    }
    if (error instanceof ContractError) {
        return new node_1.ResponseError((0, errors_1.wireErrorNumber)(error.code), error.message, error.data);
    }
    const known = error;
    const codes = Object.values(errors_1.WireErrorCode);
    const code = typeof known?.code === 'string' && codes.includes(known.code)
        ? known.code
        : errors_1.WireErrorCode.Internal;
    const message = typeof known?.message === 'string' ? known.message : String(error);
    return new node_1.ResponseError((0, errors_1.wireErrorNumber)(code), message, { code, family: generated_1.ERROR_FAMILY[code] });
}
/** The error a failed request rejects with on this side. */
function fromWire(error, closed) {
    if (error instanceof node_1.ResponseError) {
        const data = error.data;
        if (data && typeof data.code === 'string') {
            const { code, ...rest } = data;
            return new ContractError(code, error.message, rest);
        }
        if (closed) {
            return new ContractError(errors_1.WireErrorCode.DaemonUnavailable, 'The connection closed before the answer came.');
        }
        return new ContractError(errors_1.WireErrorCode.InvalidRequest, error.message);
    }
    if (closed) {
        return new ContractError(errors_1.WireErrorCode.DaemonUnavailable, 'The connection closed before the answer came.');
    }
    return error instanceof Error ? error : new Error(String(error));
}
let nextProgressToken = 0;
function createEndpoint(stream, options = {}) {
    const max = options.maxMessageBytes ?? exports.DEFAULT_MAX_MESSAGE_BYTES;
    const guard = new FrameGuard(max, (bytes) => options.onOversize?.(bytes));
    stream.pipe(guard);
    const connection = (0, node_1.createMessageConnection)(new node_1.StreamMessageReader(guard), new node_1.StreamMessageWriter(stream));
    let closed = false;
    /** The other side ended its stream; what it sent before that is still being handled. */
    let ending = false;
    const closeListeners = [];
    const inFlight = new Set();
    const shutdown = () => {
        if (closed) {
            return;
        }
        closed = true;
        ending = true;
        for (const controller of inFlight) {
            controller.abort();
        }
        inFlight.clear();
        // Disposing rejects every pending request at once.
        connection.dispose();
        stream.destroy();
        for (const listener of closeListeners.splice(0)) {
            try {
                listener();
            }
            catch { /* a listener's own failure */ }
        }
    };
    // The other side ended its stream. Its last messages may still be decoding or queued: the guard
    // ends with a marker of this side's own behind them, and the requests still pending fail only
    // once the marker is handled, after every answer and notification that arrived before the end.
    const peerGone = () => {
        if (closed || ending) {
            return;
        }
        ending = true;
        if (!guard.writableEnded) {
            guard.end();
        }
    };
    connection.onNotification(DRAINED, shutdown);
    guard.on('truncated', shutdown);
    guard.on('error', shutdown);
    stream.on('error', shutdown);
    stream.on('close', peerGone);
    stream.on('end', peerGone);
    connection.onClose(peerGone);
    connection.onError(() => { });
    connection.listen();
    return {
        get closed() { return closed || ending; },
        async request(method, params, requestOptions = {}) {
            if (closed || ending) {
                throw new ContractError(errors_1.WireErrorCode.DaemonUnavailable, 'The connection is closed.');
            }
            const source = new node_1.CancellationTokenSource();
            const abort = () => source.cancel();
            if (requestOptions.signal?.aborted) {
                throw new ContractError(errors_1.WireErrorCode.Cancelled, `${method} was cancelled before it was sent.`);
            }
            requestOptions.signal?.addEventListener('abort', abort, { once: true });
            let progress;
            let sent = params;
            if (requestOptions.onProgress) {
                const token = `p${++nextProgressToken}`;
                progress = connection.onProgress(PROGRESS, token, requestOptions.onProgress);
                sent = { ...params, [PROGRESS_TOKEN]: token };
            }
            try {
                return await connection.sendRequest(method, sent, source.token);
            }
            catch (error) {
                throw fromWire(error, closed);
            }
            finally {
                requestOptions.signal?.removeEventListener('abort', abort);
                progress?.dispose();
                source.dispose();
            }
        },
        notify(method, params) {
            if (closed) {
                return;
            }
            void connection.sendNotification(method, params).catch(() => { });
        },
        onRequest(method, handler) {
            connection.onRequest(method, async (params, token) => {
                const controller = new AbortController();
                inFlight.add(controller);
                const cancel = token.onCancellationRequested(() => controller.abort());
                const token$ = params?.[PROGRESS_TOKEN];
                const clean = token$ === undefined ? params : (() => {
                    const rest = { ...params };
                    delete rest[PROGRESS_TOKEN];
                    return rest;
                })();
                const context = {
                    signal: controller.signal,
                    progress: (value) => {
                        if (typeof token$ === 'string' && !closed) {
                            void connection.sendProgress(PROGRESS, token$, value).catch(() => { });
                        }
                    },
                };
                try {
                    const result = await handler(clean, context);
                    if (controller.signal.aborted) {
                        throw new ContractError(errors_1.WireErrorCode.Cancelled, `${method} was cancelled.`);
                    }
                    return result === undefined ? null : result;
                }
                catch (error) {
                    if (controller.signal.aborted && !(error instanceof ContractError)) {
                        throw toResponseError(new ContractError(errors_1.WireErrorCode.Cancelled, `${method} was cancelled.`));
                    }
                    throw toResponseError(error);
                }
                finally {
                    cancel.dispose();
                    inFlight.delete(controller);
                }
            });
        },
        onAnyRequest(handler) {
            connection.onRequest(async (method, params) => {
                try {
                    const result = await handler(method, params);
                    return result === undefined ? null : result;
                }
                catch (error) {
                    throw toResponseError(error);
                }
            });
        },
        onNotification(method, handler) {
            connection.onNotification(method, (params) => {
                try {
                    handler(params);
                }
                catch { /* a handler's own failure */ }
            });
        },
        onClose(listener) {
            if (closed) {
                queueMicrotask(listener);
                return;
            }
            closeListeners.push(listener);
        },
        close: shutdown,
    };
}
