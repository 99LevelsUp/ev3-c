/**
 * Errors as they cross the wire.
 *
 * A JSON-RPC error carries a numeric `code` and a `data` object, the contract's `ErrorData`. The
 * number tells a client only which family the error belongs to; what a client decides on is
 * `data.code`, a stable string, with `data.family` beside it.
 */
import type { ErrorData } from './generated';
/**
 * Every code a client may see in `data.code`, by name: exactly the contract's generated
 * `ErrorCode`, which the compiler holds this table to both ways.
 */
export declare const WireErrorCode: {
    readonly TransportFailed: "transport_failed";
    readonly ConnectionFailed: "connection_failed";
    readonly Timeout: "timeout";
    readonly ProtocolFailed: "protocol_failed";
    readonly InvalidBrickKey: "invalid_brick_key";
    readonly SessionFailed: "session_failed";
    readonly HeartbeatFailed: "heartbeat_failed";
    readonly AlreadyConnected: "already_connected";
    readonly NotConnected: "not_connected";
    readonly NoProvider: "no_provider";
    readonly InvalidTransition: "invalid_transition";
    readonly ChannelChanged: "channel_changed";
    readonly ConnectionAbandoned: "connection_abandoned";
    readonly QueueUnavailable: "queue_unavailable";
    readonly ConsumerFailed: "consumer_failed";
    readonly SubscriptionFailed: "subscription_failed";
    readonly ProgramRunning: "program_running";
    readonly ProgramNotFound: "program_not_found";
    readonly ModeConflict: "mode_conflict";
    readonly AccessDenied: "access_denied";
    /** A brick name matched several bricks; `data.candidates` lists them. */
    readonly BrickAmbiguous: "brick_ambiguous";
    /** No brick matches the name or id. */
    readonly BrickNotFound: "brick_not_found";
    /** The brick did not answer where it was expected. */
    readonly BrickUnreachable: "brick_unreachable";
    /** The link to the brick dropped during the operation. */
    readonly LinkLost: "link_lost";
    /** The operating system's USB or Bluetooth stack is not there or not working. */
    readonly BackendUnavailable: "backend_unavailable";
    /** The operating system refused the daemon the device. */
    readonly DevicePermission: "device_permission";
    /** Another client holds the brick's write lease; `data.holder` names it. */
    readonly BrickBusy: "brick_busy";
    /** The operation needs a person's answer, and the client could not ask one; `data.command` is what they can run. */
    readonly NeedsPerson: "needs_person";
    /** The daemon is not reachable, could not start, or went away during the call. */
    readonly DaemonUnavailable: "daemon_unavailable";
    /** The daemon went away during a call that changes a brick; whether it took effect is unknown. Do not retry blindly. */
    readonly OutcomeUnknown: "outcome_unknown";
    /** A replay daemon has no recorded reply left for the request: the recording is stale. */
    readonly ReplayUnmatched: "replay_unmatched";
    /** The caller, a stop or the daemon cancelled the operation. */
    readonly Cancelled: "cancelled";
    /** The request was malformed or named something the daemon does not have. */
    readonly InvalidRequest: "invalid_request";
    /** Anything else; the message says what. */
    readonly Internal: "internal";
};
export type WireErrorCode = (typeof WireErrorCode)[keyof typeof WireErrorCode];
/**
 * The numeric JSON-RPC code for each family, as the contract defines it. JSON-RPC reserves
 * -32768..-32000 for itself and for the library underneath, so the contract's own codes are
 * positive.
 */
export declare const WIRE_ERROR_NUMBER: {
    readonly cancelled: number;
    readonly brick: number;
    readonly lease: number;
    readonly person: number;
    readonly daemon: number;
    readonly request: number;
    readonly internal: number;
};
/** The numeric family a string code belongs to, from the contract's family table. */
export declare function wireErrorNumber(code: WireErrorCode): number;
/** What `data` carries on every contract error: the contract's `ErrorData`. */
export type WireErrorData = ErrorData;
